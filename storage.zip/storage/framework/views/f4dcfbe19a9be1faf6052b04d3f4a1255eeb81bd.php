
<?php $__env->startSection('content'); ?>
<style>
    label {
        margin-top: 20px;
    }
    label.error {
        color: red; /* Change 'red' to your desired text color */
        font-size: 12px; /* Adjust font size if needed */
        /* Add any other styling as per your design */
    }
</style>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="sparkline12-list">
            <div class="sparkline12-hd">
                <div class="main-sparkline12-hd">
                    <center><h1>Add Purchase Data</h1></center>
                </div>
            </div>
            <div class="sparkline12-graph">
                <div class="basic-login-form-ad">
                    <div class="row">
                        <?php if(session('msg')): ?>
                            <div class="alert alert-<?php echo e(session('status')); ?>">
                                <?php echo e(session('msg')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <?php if(Session::get('status') == 'success'): ?>
                            <div class="col-md-12">
                                <div class="alert alert-success alert-dismissible" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <strong>Success!</strong> <?php echo e(Session::get('msg')); ?>

                                </div>
                            </div>
                        <?php endif; ?>

                        <?php if(Session::get('status') == 'error'): ?>
                            <div class="col-md-12">
                                <div class="alert alert-danger alert-dismissible" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <strong>Error!</strong> <?php echo session('msg'); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="all-form-element-inner">
                                    <form action="<?php echo e(route('store-purchases')); ?>" method="POST" id="addDesignsForm" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group-inner">
                                            <div class="row">
                                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                    <label for="name"> Name:</label>
                                                    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Employee name">
                                                </div>
                                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                    <label for="email">Email:</label>
                                                    <input type="text" class="form-control" id="email" name="email" placeholder="Enter email">
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                    <label for="price">Price:</label>
                                                    <input type="text" class="form-control" id="price" name="price" placeholder="Enter price ">
                                                </div>
                                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                    <label for="contact">Contact:</label>
                                                    <input type="text" class="form-control" id="contact" name="contact" placeholder="Enter contact number">
                                                </div>
                                            </div>
                                           

                                            <div class="login-btn-inner">
                                                <div class="row">
                                                    <div class="col-lg-5"></div>
                                                    <div class="col-lg-7">
                                                        <div class="login-horizental cancel-wp pull-left">
                                                            <a href="<?php echo e(route('list-purchases')); ?>" class="btn btn-white" style="margin-bottom:50px">Cancel</a>
                                                            <button class="btn btn-sm btn-primary login-submit-cs" type="submit" style="margin-bottom:50px">Save Data</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script>
    jQuery.noConflict();
    jQuery(document).ready(function ($) {
        $("#addDesignsForm").validate({
            rules: {
                name: {
                    required: true,
                },
                email: {
                    required: true,
                    // Add your custom validation rule if needed
                },
                price: {
                    required: true,
                },
                contact: {
                    required: true,
                },
           
            },
            messages: {
                name: {
                    required: "Please enter design name.",
                },
                email: {
                    required: "Please enter a valid design page.",
                },
                price: {
                    required: "Please enter project name.",
                },
                contact: {
                    required: "Please enter time allocated for design.",
                },
               
            },
        });
    });
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerang\resources\views/organizations/productions/purchases/add-purchases.blade.php ENDPATH**/ ?>