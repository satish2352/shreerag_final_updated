
<?php $__env->startSection('content'); ?>
    <style>
        label {
            margin-top: 20px;
        }

        label.error {
            color: red;
            /* Change 'red' to your desired text color */
            font-size: 12px;
            /* Adjust font size if needed */
            /* Add any other styling as per your design */
        }
    </style>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="sparkline12-list">
                <div class="sparkline12-hd">
                    <div class="main-sparkline12-hd">
                        <center>
                            <h1>Edit Production Data</h1>
                        </center>
                    </div>
                </div>
                <div class="sparkline12-graph">
                    <div class="basic-login-form-ad">
                        <div class="row">
                            <?php if(session('msg')): ?>
                                <div class="alert alert-<?php echo e(session('status')); ?>">
                                    <?php echo e(session('msg')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <?php if(Session::has('status')): ?>
                                    <div class="col-md-12">
                                        <div class="alert alert-<?php echo e(Session::get('status')); ?> alert-dismissible"
                                            role="alert">
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <strong><?php echo e(ucfirst(Session::get('status'))); ?>!</strong>
                                            <?php echo e(Session::get('msg')); ?>

                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="all-form-element-inner">
                                        <form
                                            action="<?php echo e(route('update-gatepass')); ?>"
                                            method="POST" id="editDesignsForm" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="container-fluid">

                                                <div class="form-group-inner">
                                                    <div class="row">
                                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                            <label for="purchase_orders_id">PO :</label>
                                                            <input type="text" class="form-control"
                                                                id="purchase_orders_id" name="purchase_orders_id"
                                                                value=" <?php if(old('purchase_orders_id')): ?> <?php echo e(old('purchase_orders_id')); ?><?php else: ?><?php echo e($editData->purchase_orders_id); ?> <?php endif; ?>"
                                                                placeholder="" readonly >
                                                        </div>
                                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                            <label for="gatepass_name">Name :</label>
                                                            <input type="text" class="form-control" id="gatepass_name"
                                                                name="gatepass_name"
                                                                value=" <?php if(old('gatepass_name')): ?> <?php echo e(old('gatepass_name')); ?><?php else: ?><?php echo e($editData->gatepass_name); ?> <?php endif; ?>"
                                                                placeholder="Enter the Name">
                                                        </div>
                                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                            <label for="gatepass_date">Date: <span
                                                                    class="text-danger">*</span></label>
                                                            <input type="date" class="form-control" name="gatepass_date"
                                                                id="gatepass_date" placeholder="Select Date"
                                                                value="<?php echo e(old('gatepass_date', $editData->gatepass_date)); ?>">
                                                        </div>
                                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                            <label for="gatepass_time">Time :</label>
                                                            <input type="time" class="form-control" id="gatepass_time"
                                                                name="gatepass_time"
                                                                value="<?php echo e(old('gatepass_time', $editData->gatepass_time)); ?>"
                                                                placeholder="Select Time">
                                                        </div>
                                                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                            <label for="remark">Remark :</label>
                                                            <input type="text" class="form-control" id="remark"
                                                                name="remark"
                                                                value=" <?php if(old('remark')): ?> <?php echo e(old('remark')); ?><?php else: ?><?php echo e($editData->remark); ?> <?php endif; ?>"
                                                                placeholder="Enter  Remark">
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="login-btn-inner">
                                                    <div class="row">
                                                        <div class="col-lg-5"></div>
                                                        <div class="col-lg-7">
                                                            <div class="login-horizental cancel-wp pull-left">
                                                                <a href="<?php echo e(route('list-products')); ?>"
                                                                    class="btn btn-white"
                                                                    style="margin-bottom:50px">Cancel</a>
                                                                <button class="btn btn-sm btn-primary login-submit-cs"
                                                                    type="submit" style="margin-bottom:50px">Update
                                                                    Data</button>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    <form method="POST" action="<?php echo e(route('delete-addmore')); ?>" id="deleteform">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="delete_id" id="delete_id" value="">
    </form>
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script>
var i = 0;



</script>
<script>
jQuery.noConflict();
jQuery(document).ready(function($) {
    function setMinDate() {
                var today = new Date();
                var day = String(today.getDate()).padStart(2, '0');
                var month = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
                var year = today.getFullYear();
                var todayDate = year + '-' + month + '-' + day;
    
                $('#gatepass_date').attr('min', todayDate);
            }
            setMinDate();
    $("#addDesignsForm").validate({
        rules: {          
            purchase_orders_id: {
                required: true
            },
            gatepass_name : {
                required : true
            },     
            gatepass_date : {
                required : true
            },    
            gatepass_time : {
                required : true
            },
            remark :{
                required : true,
            },           
        },
        messages: {
            purchase_orders_id: {
                required: "Please Enter Po Number.",
            },              
            gatepass_name : {
                required: "Please Enter Gatepass Name.",
            },
            gatepass_date : {
                required: "Please Select Gatepass Date.",
            },
            gatepass_time : {
                required: "Please Select Gatepass Time.",
            },
            remark : {
                required: "Please enter Remark.",
            },                      
        },
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/organizations/security/gatepass/edit-gatepass.blade.php ENDPATH**/ ?>