
<?php $__env->startSection('content'); ?>
<style>
    label {
        margin-top: 20px;
    }
</style>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="sparkline12-list">
            <div class="sparkline12-hd">
                <div class="main-sparkline12-hd">
                    <center><h1>Add roles Data</h1></center>
                </div>
            </div>
            <div class="sparkline12-graph">
                <div class="basic-login-form-ad">
                    <div class="row">
                        <?php if(session('msg')): ?>
                            <div class="alert alert-<?php echo e(session('status')); ?>">
                                <?php echo e(session('msg')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <?php if(Session::get('status') == 'success'): ?>
                                <div class="col-12 grid-margin">
                                    <div class="alert alert-custom-success " id="success-alert">
                                        <button type="button"  data-bs-dismiss="alert"></button>
                                        <strong style="color: green;">Success!</strong> <?php echo e(Session::get('msg')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(Session::get('status') == 'error'): ?>
                                <div class="col-12 grid-margin">
                                    <div class="alert alert-custom-danger " id="error-alert">
                                        <button type="button"  data-bs-dismiss="alert"></button>
                                        <strong style="color: red;">Error!</strong> <?php echo session('msg'); ?>

                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="all-form-element-inner">
                                <?php if($errors->any()): ?>
                                    <div class="alert alert-danger">
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <form action="<?php echo e(route('update-roles')); ?>" method="POST" enctype="multipart/form-data" id="editEmployeeForm" autocomplete="off">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group-inner">
                                        <input type="hidden" class="form-control" value="<?php if(old('id')): ?> <?php echo e(old('id')); ?><?php else: ?><?php echo e($editData->id); ?> <?php endif; ?>" id="id" name="id">
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                <label for="role_name">Employee Name:</label>
                                                <input type="text" class="form-control" value="<?php if(old('role_name')): ?> <?php echo e(old('role_name')); ?><?php else: ?><?php echo e($editData->role_name); ?> <?php endif; ?>" id="role_name" name="role_name" placeholder="Enter roles name">
                                            </div>
                                           
                                        </div>

                                      
                                    <div class="login-btn-inner">
                                        <div class="row">
                                            <div class="col-lg-5"></div>
                                            <div class="col-lg-7">
                                                <div class="login-horizental cancel-wp pull-left">
                                                    <a href="<?php echo e(route('list-roles')); ?>">
                                                        <button class="btn btn-white" style="margin-bottom:50px">Cancel</button>
                                                    </a>
                                                    <button class="btn btn-sm btn-primary login-submit-cs" type="submit" style="margin-bottom:50px">Save Data</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
  <script src="<?php echo e(asset('js/vendor/jquery-1.11.3.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/password-meter/pwstrength-bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/password-meter/zxcvbn.js')); ?>"></script>
    <script src="<?php echo e(asset('js/password-meter/password-meter-active.js')); ?>"></script>
  <!-- Include jQuery -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/admin/pages/roles/edit-roles.blade.php ENDPATH**/ ?>