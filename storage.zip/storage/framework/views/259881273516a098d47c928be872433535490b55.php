
<?php $__env->startSection('content'); ?>
<section>
    <!-- immer banner start -->
    <section class="inner-banner pt-80 pb-95" style="background-image: url('<?php echo e(asset('website/assets/img/banner/inner-banner.jpg')); ?>');" data-overlay="7">
        <div class="container">
            <div class="row z-5 align-items-center">
                <div class="col-md-8 text-center text-md-left">
                    <h1 class="f-700 white">Product Details</h1>
                    
                </div>
                
            </div>
        </div>
    </section>

    <section class="team-detail pt-40 pb-20">
        <div class="container">
        <?php $__empty_1 = true; $__currentLoopData = $data_output_product_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="row">
                <div class="col-lg-4">
                    <div class="team-detail-image">
                        <div class="team-member-image img-lined">
                            <img src="<?php echo e(Config::get('DocumentConstant.PRODUCT_VIEW')); ?><?php echo e($product['image']); ?>" alt="">
                            
                        </div>
                        
                    </div>
                </div>
                <div class="col-lg-8 mb-70 ">
                    <h2 class="f-700 mb-20"><?php echo e($product['title']); ?></h2>
                    <h5><?php echo e($product['description']); ?></h5>
                    
                    
                    <!-- <a href="#" class="btn btn-round mt-5">Order Now</a> -->
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>
                <?php if(session('language') == 'mar'): ?>
                    <?php echo e(Config::get('marathi.PARTICULAR_DEPARTMENT_INFORMATION.NO_DEPARTMENT_INFORMATION')); ?>

                <?php else: ?>
                    <?php echo e(Config::get('english.PARTICULAR_DEPARTMENT_INFORMATION.NO_DEPARTMENT_INFORMATION')); ?>

                <?php endif; ?>
            </p>
        <?php endif; ?>
        </div>
    </section>

</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/website/pages/product_details.blade.php ENDPATH**/ ?>