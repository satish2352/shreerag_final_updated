
<?php $__env->startSection('content'); ?>
<style>
    label {
        margin-top: 20px;
    }
    label.error {
        color: red; /* Change 'red' to your desired text color */
        font-size: 12px; /* Adjust font size if needed */
        /* Add any other styling as per your design */
    }
</style>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="sparkline12-list"  style="padding-bottom: 100px">
            <div class="sparkline12-hd">
                <div class="main-sparkline12-hd">
                    <center><h1>Edit Employee Data</h1></center>
                </div>
            </div>
            <div class="sparkline12-graph">
                <div class="basic-login-form-ad">
                    <div class="row">
                        <?php if(session('msg')): ?>
                            <div class="alert alert-<?php echo e(session('status')); ?>">
                                <?php echo e(session('msg')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <?php if(Session::get('status') == 'success'): ?>
                                <div class="col-12 grid-margin">
                                    <div class="alert alert-custom-success " id="success-alert">
                                        <button type="button"  data-bs-dismiss="alert"></button>
                                        <strong style="color: green;">Success!</strong> <?php echo e(Session::get('msg')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(Session::get('status') == 'error'): ?>
                                <div class="col-12 grid-margin">
                                    <div class="alert alert-custom-danger " id="error-alert">
                                        <button type="button"  data-bs-dismiss="alert"></button>
                                        <strong style="color: red;">Error!</strong> <?php echo session('msg'); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <div class="all-form-element-inner">
                                <form class="forms-sample" id="regForm" name="frm_register" method="post" role="form"
                                action="<?php echo e(route('update-users')); ?>" enctype="multipart/form-data">
                                <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
                                <div class="row">
                                    
                                    

                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label for="role_id">Role Type</label>&nbsp<span class="red-text">*</span>
                                            <select class="form-control" id="role_id" name="role_id"
                                                onchange="myFunction(this.value)">
                                                <option>Select</option>
                                                <?php $__currentLoopData = $user_data['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($role['id']); ?>"
                                                        <?php if($role['id'] == $user_data['data_users']['role_id']): ?> <?php echo 'selected'; ?> <?php endif; ?>>
                                                        <?php echo e($role['role_name']); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('role_id')): ?>
                                                <span class="red-text"><?php echo $errors->first('role_id', ':message'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label for="f_name">First Name</label>&nbsp<span class="red-text">*</span>
                                            <input type="text" class="form-control mb-2" name="f_name" id="f_name"
                                                placeholder="" value="<?php echo e($user_data['data_users']['f_name']); ?>"
                                                oninput="this.value = this.value.replace(/[^a-zA-Z\s.]/g, '').replace(/(\..*)\./g, '$1');">
                                            <?php if($errors->has('f_name')): ?>
                                                <span class="red-text"><?php echo $errors->first('f_name', ':message'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label for="m_name">Middle Name</label>&nbsp<span class="red-text">*</span>
                                            <input type="text" class="form-control mb-2" name="m_name" id="m_name"
                                                placeholder="" value="<?php echo e($user_data['data_users']['m_name']); ?>"
                                                oninput="this.value = this.value.replace(/[^a-zA-Z\s.]/g, '').replace(/(\..*)\./g, '$1');">
                                            <?php if($errors->has('m_name')): ?>
                                                <span class="red-text"><?php echo $errors->first('m_name', ':message'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label for="l_name">Last Name</label>&nbsp<span class="red-text">*</span>
                                            <input type="text" class="form-control mb-2" name="l_name" id="l_name"
                                                placeholder="" value="<?php echo e($user_data['data_users']['l_name']); ?>"
                                                oninput="this.value = this.value.replace(/[^a-zA-Z\s.]/g, '').replace(/(\..*)\./g, '$1');">
                                            <?php if($errors->has('l_name')): ?>
                                                <span class="red-text"><?php echo $errors->first('l_name', ':message'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label for="number">Number</label>&nbsp<span class="red-text">*</span>
                                            <input type="text" class="form-control mb-2" name="number" id="number"
                                                placeholder="" value="<?php echo e($user_data['data_users']['number']); ?>"
                                                onkeyup="editvalidateMobileNumber(this.value)"
                                                pattern="[789]{1}[0-9]{9}" oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"  maxlength="10" minlength="10"
                                                >
                                            <span id="edit-message" class="red-text"></span>
                                            <?php if($errors->has('number')): ?>
                                                <span class="red-text"><?php echo $errors->first('number', ':message'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label for="designation">Designation</label>&nbsp<span class="red-text">*</span>
                                            <input type="text" class="form-control mb-2" name="designation" id="designation"
                                                placeholder="" value="<?php echo e($user_data['data_users']['designation']); ?>"
                                                oninput="this.value = this.value.replace(/[^a-zA-Z\s.]/g, '').replace(/(\..*)\./g, '$1');">
                                            <?php if($errors->has('designation')): ?>
                                                <span class="red-text"><?php echo $errors->first('designation', ':message'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label for="address">Address</label>&nbsp<span class="red-text">*</span>
                                            <input type="text" class="form-control mb-2" name="address" id="address"
                                                placeholder="" value="<?php echo e($user_data['data_users']['address']); ?>">
                                            <?php if($errors->has('address')): ?>
                                                <span class="red-text"><?php echo $errors->first('address', ':message'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label for="state">State</label>&nbsp;<span class="red-text">*</span>
                                            <select class="form-control mb-2" name="state" id="state">
                                                <option value="">Select State</option>
                                            </select>
                                            <?php if($errors->has('state')): ?>
                                                <span class="red-text"><?php echo $errors->first('state', ':message'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label for="city">City</label>&nbsp;<span class="red-text">*</span>
                                            <select class="form-control mb-2" name="city" id="city">
                                                <option value="">Select City</option>
                                            </select>
                                            <?php if($errors->has('city')): ?>
                                                <span class="red-text"><?php echo $errors->first('city', ':message'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group">
                                            <label for="pincode">Pincode</label>&nbsp<span class="red-text">*</span>
                                            <input type="text" class="form-control mb-2" name="pincode" id="pincode"
                                                placeholder="" value="<?php echo e($user_data['data_users']['pincode']); ?>"
                                                onkeyup="editvalidatePincode(this.value)">
                                            <span id="edit-message-pincode" class="red-text"></span>
                                            <?php if($errors->has('pincode')): ?>
                                                <span class="red-text"><?php //echo $errors->first('pincode', ':message'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    

                                    <br>
                                    <div class="col-lg-6 col-md-6 col-sm-6">
                                        <div class="form-group form-check form-check-flat form-check-primary">
                                            <label class="form-check-label">
                                                <input type="checkbox" class="form-check-input" name="is_active"
                                                    id="is_active" value="y" data-parsley-multiple="is_active"
                                                    <?php if($user_data['data_users']['is_active']): ?> <?php echo 'checked'; ?> <?php endif; ?>>
                                                Is Active
                                                <i class="input-helper"></i><i class="input-helper"></i></label>
                                        </div>
                                    </div>

                                    

                                    <div class="col-md-12 col-sm-12 text-center mt-3">
                                        <input type="hidden" class="form-check-input" name="edit_id" id="edit_id"
                                            value="<?php echo e($user_data['data_users']['id']); ?>">
                                            <button type="submit" class="btn btn-sm btn-success" id="submitButton">
                                                Save &amp; Update
                                            </button>
                                        
                                        <span><a href="<?php echo e(route('list-users')); ?>"
                                                class="btn btn-sm btn-primary ">Back</a></span>
                                    </div>
                                    
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script> <!-- Include SweetAlert library -->

<script>
    function getStateCity(stateId, city_id) {
        $('#city').html('<option value="">Select City</option>');
        if (stateId !== '') {
            $.ajax({
                url: '<?php echo e(route('cities')); ?>',
                type: 'GET',
                data: { stateId: stateId },
                success: function(response) {
                    if (response.city.length > 0) {
                        $.each(response.city, function(index, city) {
                            $('#city').append('<option value="' + city.location_id + '">' + city.name + '</option>');
                        });
                        if (city_id != null) {
                            $('#city').val(city_id);
                        }
                    }
                }
            });
        }
    }

    function getState(stateId) {
        $('#state').html('<option value="">Select State</option>');
        $.ajax({
            url: '<?php echo e(route('states')); ?>',
            type: 'GET',
            success: function(response) {
                if (response.state.length > 0) {
                    $.each(response.state, function(index, state) {
                        $('#state').append('<option value="' + state.location_id + '">' + state.name + '</option>');
                    });
                    $('#state').val(stateId);
                }
            }
        });
    }

    $(document).ready(function() {
        getState('<?php echo e($user_data['data_users']['state']); ?>');
        getStateCity('<?php echo e($user_data['data_users']['state']); ?>', '<?php echo e($user_data['data_users']['city']); ?>');

        $("#state").on('change', function() {
            getStateCity($(this).val(), '');
        });
    });
</script>

<script type="text/javascript">
    function submitRegister() {
        document.getElementById("frm_register").submit();
    }
</script>
<script>
    function editvalidateMobileNumber(number) {
        var mobileNumberPattern = /^\d*$/;
        var validationMessage = document.getElementById("edit-message");

        if (mobileNumberPattern.test(number)) {
            validationMessage.textContent = "";
        } else {
            validationMessage.textContent = "Only numbers are allowed.";
        }
    }
</script>
<script>
    function editvalidatePincode(number) {
        var pincodePattern = /^\d*$/;
        var validationMessage = document.getElementById("edit-message-pincode");

        if (pincodePattern.test(number)) {
            validationMessage.textContent = "";
        } else {
            validationMessage.textContent = "Only numbers are allowed.";
        }
    }
</script>

<script>
    $(document).ready(function() {
        myFunction($("#role_id").val());
        getStateCity('<?php echo e($user_data['data_users']['state']); ?>', '<?php echo e($user_data['data_users']['city']); ?>');
        getState('<?php echo e($user_data['data_users']['state']); ?>');

        $("#state").on('change', function() {
            getStateCity($("#state").val(),'');
        });
    });

    
</script>
 <script>
    $(document).ready(function() {
        $.validator.addMethod('mypassword', function(value, element) {
                return this.optional(element) || (value.match(/[a-z]/) && value.match(/[A-Z]/) && value
                    .match(/[0-9]/));
            },
            'Password must contain at least one uppercase, lowercase and numeric');

        $("#frm_register1").validate({
            rules: {

                u_password: {
                    //required: true,
                    minlength: 6,
                    mypassword: true

                },
                password_confirmation: {
                    //required: true,
                    equalTo: "#u_password"
                },
            },
            messages: {
                u_password: {
                    required: "Please enter your new password",
                    minlength: "Password should be minimum 8 characters"
                },
                password_confirmation: {
                    required: "Please Enter Password Same as New Password for Confirmation",
                    equalTo: "Password does not Match! Please check the Password"
                }
            }
        });
    });
</script>
<script>
    $(document).ready(function() {
        $("#show_hide_password a").on('click', function(event) {
            event.preventDefault();
            if ($('#show_hide_password input').attr("type") == "text") {
                $('#show_hide_password input').attr('type', 'password');
                $('#show_hide_password i').addClass("bx-hide");
                $('#show_hide_password i').removeClass("bx-show");
            } else if ($('#show_hide_password input').attr("type") == "password") {
                $('#show_hide_password input').attr('type', 'text');
                $('#show_hide_password i').removeClass("bx-hide");
                $('#show_hide_password i').addClass("bx-show");
            }
        });
    });
</script>
<script>
$(document).ready(function() {
// Function to check if all input fields are filled with valid data
function checkFormValidity() {
    const role_id = $('#role_id').val();
    const f_name = $('#f_name').val();
    const m_name = $('#m_name').val();
    const l_name = $('#l_name').val();
    const number = $('#number').val();
    const designation = $('#designation').val();
    const address = $('#address').val();
    const state = $('#state').val();
    const city = $('#city').val();
    // const user_profile = $('#user_profile').val();
    const pincode = $('#pincode').val();
    
}

// Call the checkFormValidity function on file input change
$('input, #english_image, #marathi_image').on('change', function() {
    checkFormValidity();
    validator.element(this); // Revalidate the file input
});
// Initialize the form validation
var form = $("#regForm");
var validator = form.validate({
    rules: {
        // u_email: {
        //     required: true,
        // },
        role_id: {
            required: true,
        },
        // u_password: {
        //     required: true,
        // },
        // password_confirmation: {
        //     required: true,
        // },
        f_name: {
            required: true,
        },
        m_name: {
            required: true,
        },
        l_name: {
            required: true,
        },
        number: {
            required: true,
        },
        designation: {
            required: true,
        },
        address: {
            required: true,
        },
        state: {
            required: true,
        },
        city: {
            required: true,
        },
        // user_profile: {
        //     required: true,
        // },
        pincode: {
            required: true,
        },
    },
    messages: {
        // u_email: {
        //     required: "Please Enter the Eamil",
        // },
        role_id: {
            required: "Please Select Role Name",
        },
        // u_password: {
        //     required: "Please Enter the Password",
        // },
        // password_confirmation: {
        //     required: "Please Enter the Confirmation Password",
        // },
        f_name: {
            required: "Please Enter the First Name",
        },
        m_name: {
            required: "Please Enter the Middle Name",
        },
        l_name: {
            required: "Please Enter the Last Name",
        },
        number: {
            required: "Please Enter the Number",
        },
        designation: {
            required: "Please Enter the Designation",
        },
        address: {
            required: "Please Enter the Address",
        },

        state: {
            required: "Please Select State",
        },
        city: {
            required: "Please Select State",
        },
        // user_profile: {
        //     required: "Upload Media File",
        //     accept: "Only png, jpeg, and jpg image files are allowed.", // Update the error message for the accept rule
        // },
        pincode: {
            required: "Please Enter the Pincode",
        },
    },
    submitHandler: function(form) {
        form.submit();
    }
});

// Submit the form when the "Update" button is clicked
$("#submitButton").click(function() {
    // Validate the form
    if (form.valid()) {
        form.submit();
    }
});
});
</script>    



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/organizations/hr/employees/edit-employees.blade.php ENDPATH**/ ?>