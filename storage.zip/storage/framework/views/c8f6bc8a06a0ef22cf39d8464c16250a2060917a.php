
<?php $__env->startSection('content'); ?>
<section>

 <!-- bannar start -->
 <div class="banrimgs">
    <img src="<?php echo e(asset('website/assets/img/banner/PRODUCT.png')); ?>" alt="">
</div>
<div class="mobibanrimgs">
  <img src="<?php echo e(asset('website/assets/img/banner/mobprod.png')); ?>" alt="">
</div>
<!-- bannar end -->

 

    <!-- Product area start -->
    
        
    
         <!-- Product area start -->
    
        <div class="container-fluid testmo1 team-area pt-50 pb-5">
            <div class="row ">

                <?php if(empty($data_output_product)): ?>
                <div class="container">
                    <div class="row d-flex justify-content-center">
                        <h3 class="d-flex justify-content-center" style="color: #00000">No Data Found For
                            Product</h3>
                    </div>
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $data_output_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xl-4 col-lg-6 col-md-6 p-4">
                    <div class="team-each team1 prosha  ">
                        <div class="team-image  relative">
                            
                            <img src="<?php echo e(Config::get('DocumentConstant.PRODUCT_VIEW')); ?><?php echo e($product['image']); ?>" alt="">            
                        </div>
                        <div class="team-info transition-4">
                            <h3 class="ml-30">
                            <a 
                           
                            data-id="<?php echo e($product['id']); ?>"

                            
                             class="show-btn f-700"><?php echo e($product['title']); ?></a>
                            </h3>
                            <p class="mb-0 ml-30"><a 
                                data-id="<?php echo e($product['id']); ?>"
                                
                                 class="show-btn btn btn-round-blue wide mt-10 z-8">Product</a></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              

            </div>
            
        </div>
    
    
    <!-- Product area end -->
    <form method="POST" action="<?php echo e(url('/product-details')); ?>" id="showform">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="show_id" id="show_id" value="">
    </form>
    <section>
        <div class="pt-35 pb-50 hidd">
                  <!-- bannar start -->
                  <div class="banrimgs">
                    <img src="<?php echo e(asset('website/assets/img/banner/HOME_PAGE31.png')); ?>" alt="">
                </div>
                <div class="mobibanrimgs">
                <img src="<?php echo e(asset('website/assets/img/banner/mobconnect.jpg')); ?>" alt="">
                </div>
            <!-- bannar end -->
    
        </div>
    </section>
  
</section>
<script src="<?php echo e(asset('js/vendor/jquery-1.11.3.min.js')); ?>"></script>
<script>
    $('.show-btn').click(function(e) {
        $("#show_id").val($(this).attr("data-id"));
        $("#showform").submit();
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/website/pages/product.blade.php ENDPATH**/ ?>