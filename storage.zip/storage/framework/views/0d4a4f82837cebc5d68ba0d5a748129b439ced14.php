<?php if(Session::get('status') == 'success'): ?>
    <div class="col-12 grid-margin">
        <div class="alert alert-success" id="success-alert">
            <button type="button" class="close" data-dismiss="alert">x</button>
            <strong> <span id="data_to_show">
                    <?php echo e(Session::get('msg')); ?>

                </span> </strong>
        </div>
    </div>
<?php endif; ?>

<?php if(Session::get('status') == 'error'): ?>
    <div class="col-12 grid-margin">
        <div class="alert alert-danger" id="danger-alert">
            <button type="button" class="close" data-dismiss="alert">x</button>
            <strong> <span id="data_to_show">
                    <?php echo session('msg'); ?>

                </span> </strong>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/admin/layouts/alert.blade.php ENDPATH**/ ?>