
<?php $__env->startSection('content'); ?>
<section>

 <!-- bannar start -->
 <div class="banrimgs">
    <img src="<?php echo e(asset('website/assets/img/banner/PRODUCT.png')); ?>" alt="">
</div>
<div class="mobibanrimgs">
  <img src="<?php echo e(asset('website/assets/img/banner/mobprod.png')); ?>" alt="">
</div>
<!-- bannar end -->

 

    <!-- Product area start -->
    
        
    
         <!-- Product area start -->
    
        <div class="container-fluid testmo1 team-area pt-50 pb-5">
            <div class="row ">

                <div class="col-xl-4 col-lg-4 col-md-6 p-3">
                    <div class="team-each team1 prosha ml-20 mb-40">
                        <div class="team-image  relative">
                            <img src="<?php echo e(asset('website/assets/img/products/prod1.png')); ?>" alt="">            
                        </div>
                        <div class="team-info transition-4">
                            <h3 class="ml-30">
                            <a href="<?php echo e(url('/product_details')); ?>" class="f-700">Parts Trolley</a>
                            </h3>
                            <p class="mb-0 ml-30"><a href="<?php echo e(url('/product_details')); ?>" class="btn btn-round-blue wide mt-10 z-8">Product</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 p-3">
                    <div class="team-each team1 prosha ml-20 mb-40">
                        <div class="team-image relative">
                            <img src="<?php echo e(asset('website/assets/img/products/prod2.png')); ?>" alt="">
                           
                        </div>
                        <div class="team-info transition-4">
                            <h3 class="ml-30">
                                <a href="<?php echo e(url('/product_details')); ?>" class="f-700">Parts Trolley</a>
                                </h3>
                                <p class="mb-0 ml-30"><a href="<?php echo e(url('/product_details')); ?>" class="btn btn-round-blue wide mt-10 z-8">Product</a></p>
                            </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 p-3">
                    <div class="team-each team1 prosha ml-20 mb-40">
                        <div class="team-image relative">
                            <img src="<?php echo e(asset('website/assets/img/products/prod3.png')); ?>" alt="">
                           
                        </div>
                        <div class="team-info transition-4">
                            <h3 class="ml-30">
                                <a href="<?php echo e(url('/product_details')); ?>" class="f-700">Parts Trolley</a>
                                </h3>
                                <p class="mb-0 ml-30"><a href="<?php echo e(url('/product_details')); ?>" class="btn btn-round-blue wide mt-10 z-8">Product</a></p>
                            </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 p-3">
                    <div class="team-each team1 prosha ml-20 mb-40">
                        <div class="team-image relative">
                            <img src="<?php echo e(asset('website/assets/img/products/prod4.png')); ?>" alt="">
                            
                        </div>
                        <div class="team-info transition-4">
                            <h3 class="ml-30">
                                <a href="<?php echo e(url('/product_details')); ?>" class="f-700">Parts Trolley</a>
                                </h3>
                                <p class="mb-0 ml-30"><a href="<?php echo e(url('/product_details')); ?>" class="btn btn-round-blue wide mt-10 z-8">Product</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 p-3">
                    <div class="team-each team1 prosha ml-20 mb-40">
                        <div class="team-image relative">
                            <img src="<?php echo e(asset('website/assets/img/products/prod5.png')); ?>" alt="">
                           
                        </div>
                        <div class="team-info transition-4">
                            <h3 class="ml-30">
                                <a href="<?php echo e(url('/product_details')); ?>" class="f-700">Parts Trolley</a>
                                </h3>
                                <p class="mb-0 ml-30"><a href="<?php echo e(url('/product_details')); ?>" class="btn btn-round-blue wide mt-10 z-8">Product</a></p>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 p-3">
                    <div class="team-each team1 prosha ml-20 mb-40">
                        <div class="team-image relative">
                            <img src="<?php echo e(asset('website/assets/img/products/prod6.png')); ?>" alt="">
                           
                        </div>
                        <div class="team-info transition-4">
                            <h3 class="ml-30">
                                <a href="<?php echo e(url('/product_details')); ?>" class="f-700">Parts Trolley</a>
                                </h3>
                                <p class="mb-0 ml-30"><a href="<?php echo e(url('/product_details')); ?>" class="btn btn-round-blue wide mt-10 z-8">Product</a></p>
                            </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 p-3">
                    <div class="team-each team1 prosha ml-20 mb-40">
                        <div class="team-image relative">
                            <img src="<?php echo e(asset('website/assets/img/products/prod1.png')); ?>" alt="">
                           
                        </div>
                        <div class="team-info transition-4">
                            <h3 class="ml-30">
                                <a href="<?php echo e(url('/product_details')); ?>" class="f-700">Parts Trolley</a>
                                </h3>
                                <p class="mb-0 ml-30"><a href="<?php echo e(url('/product_details')); ?>" class="btn btn-round-blue wide mt-10 z-8">Product</a></p>
                            </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 p-3">
                    <div class="team-each team1 prosha ml-20 mb-40">
                        <div class="team-image relative">
                            <img src="<?php echo e(asset('website/assets/img/products/prod4.png')); ?>" alt="">
                            
                        </div>
                        <div class="team-info transition-4">
                            <h3 class="ml-30">
                                <a href="<?php echo e(url('/product_details')); ?>" class="f-700">Parts Trolley</a>
                                </h3>
                                <p class="mb-0 ml-30"><a href="<?php echo e(url('/product_details')); ?>" class="btn btn-round-blue wide mt-10 z-8">Product</a></p>
                             </div>
                    </div>
                </div>

                <div class="col-xl-4 col-lg-4 col-md-6 p-3">
                    <div class="team-each team1 prosha ml-20 mb-40">
                        <div class="team-image relative">
                            <img src="<?php echo e(asset('website/assets/img/products/prod2.png')); ?>" alt="">
                           
                        </div>
                        <div class="team-info transition-4">
                            <h3 class="ml-30">
                                <a href="<?php echo e(url('/product_details')); ?>" class="f-700">Parts Trolley</a>
                                </h3>
                                <p class="mb-0 ml-30"><a href="<?php echo e(url('/product_details')); ?>" class="btn btn-round-blue wide mt-10 z-8">Product</a></p>
                              </div>
                    </div>
                </div>

            </div>
            
        </div>
    
    
    <!-- Product area end -->

    <section>
        <div class="pt-35 pb-50">
                  <!-- bannar start -->
                  <div class="banrimgs">
                    <img src="<?php echo e(asset('website/assets/img/banner/HOME_PAGE31.png')); ?>" alt="">
                </div>
                <div class="mobibanrimgs">
                <img src="<?php echo e(asset('website/assets/img/banner/mobconnect.jpg')); ?>" alt="">
                </div>
            <!-- bannar end -->
    
        </div>
    </section>
  
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerang\resources\views/website/pages/product.blade.php ENDPATH**/ ?>