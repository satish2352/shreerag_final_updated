
<?php $__env->startSection('content'); ?>
<section>
    <!-- bannar start -->
    <div class="banrimgs">
        <img src="<?php echo e(asset('website/assets/img/banner/contact_us.png')); ?>" alt="">
    </div>
    <div class="mobibanrimgs">
        <img src="<?php echo e(asset('website/assets/img/banner/mobcontact.png')); ?>" alt="">
    </div>
    <!-- bannar end -->

    <!--  -->
    <section>
        <div class="contbak">
      
            
            <div class="container mb-10 pt-50 pb-10">
                

        <div class="position-relative ">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30002.54703617599!2d73.6951784831116!3d19.953108539974554!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bddecafb71b21c9%3A0xa6dab4828bb274df!2sMIDC%20Ambad%2C%20Nashik%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1707914483331!5m2!1sen!2sin"
                width="100%" id="ifrm" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>

        <div class="addrescard addresscenter  pt-20">
            <div class="card" style="width: 25rem;">
                <h4 class="card-header card-info2 text-center text-white">
                    Address
                </h4>
                <div class="card-body text-justify p-4">
                    <ul class="clrtext">
                        <li><span class="f-600">Plant No. 1</span> W-127 (A),</li>
                        <br>
                        <li><span class="f-600">Plant No. 2</span> - W-118 (A) MIDC Ambad Nashik - 422010 ,</li>
                        <br>
                        <li><span class="f-600">Plant No. 3</span> - GAT NO679/2/1 , Kurli Alandi Road ,Chankan , Tal
                            khed Dist. Pune - 410501,</li>
                        <br>
                        <li><span class="f-600">Plant No. 4</span> - GF Plot No - 913 Shreeji Engg, GIDC , Halol ,
                            Panchamahal Gujarat - 389350</li>


                    </ul>
                </div>
            </div>
        </div>
        </div>

        <div class="contcatcontainer ">
            <div class="card shadow-1">

                <div class="row">
                    <div class="col-lg-4 col-2 col-sm-4">
                        <img src="<?php echo e(asset('website/assets/img/contact/callimg1.png')); ?>" alt="">
                    </div>
                    <div class="col-lg-8 col-4 col-sm-8 contnom mt-60">
                        <div class="row">
                            <div class="col-lg-3 col-md-3 col-sm-3">
                                <h5 class="f-700 clrtext">Contact</h5>
                            </div>
                            <ul class="d-flex col-lg-9 col-md-9 col-sm-9">
                                <li><a href="tel:+91 7028082176" class="clrtext  f-600">7028082176</a>
                                </li>
                                <li><a href="tel: +91 0253 - 2383517" class="clrtext ml-20 f-600">0253-2383517</a>
                                </li>
                            </ul>


                        </div>
                        <div class="row social-links mb-20 ">
                            <div class="col-lg-5 col-md-5 mt-0 py-3">
                                <h5 class="f-700 clrtext">Follow us on</h5>

                            </div>
                            <div class="col-lg-7 col-md-7 social-links social-links1 ">
                                <ul class="social-icons sociicon">
                                    <li>
                                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                                    </li>

                                    <li>
                                        <a href="#"><i class="fab fa-instagram"></i></a>
                                    </li>
                                    <li class="email">
                                        <a href="#"><i class="fa-regular fa-envelope "></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
        </div>
        </div>
    </section>
    <div class="container card shadow-1 p-5">
        <form class="forms-sample" action="<?php echo e(url('add-contactus')); ?>" id="regForm" method="POST"
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="row py-md-2">
          <div class="col-md-6 pt-md-0 pt-2 ">
            <div class="">
              <label for="full_name"><strong style="color:#323232"> Name </strong></label>
              <input type="text" placeholder="Your Full Name" name="full_name" value="<?php echo e(old('full_name')); ?>"
                class="form-control full_nameField">
              <span id="number-validate" class="red-text"></span>
              <?php if($errors->has('full_name')): ?>
              <span class="red-text">
                <?php echo $errors->first('full_name', ':message'); ?>
              </span>
              <?php endif; ?>
            </div>
          </div>
          <div class="col-md-6">
            <div class="">
              <label for="subject"><strong style="color:#323232"> Company Name </strong></label>
              <input type="text" placeholder="Enter Company Name" name="subject" value="<?php echo e(old('subject')); ?>"
                class="form-control">
              <span id="number-validate" class="red-text"></span>
              <?php if($errors->has('subject')): ?>
              <span class="red-text">
                <?php echo $errors->first('subject', ':message'); ?>
              </span>
              <?php endif; ?>
            </div>
          </div>
          <div class="col-md-6 pt-2">
            <div class="">
              <label for="mobile_number"><strong style="color:#323232"> Mobile Number </strong></label>
              <input type="text" placeholder="Mobile Number" name="mobile_number"
                value="<?php echo e(old('mobile_number')); ?>" class="form-control" maxlength="10" minlength="10" onkeyup="addvalidateMobileNumber(this.value)">
              <span id="number-validate" class="red-text"></span>
              <?php if($errors->has('mobile_number')): ?>
              <span class="red-text">
                <?php echo $errors->first('mobile_number', ':message'); ?>
              </span>
              <?php endif; ?>

            </div>
          </div>
          <div class="col-md-6 pt-2">
            <div class="">
              <label for="email"><strong style="color:#323232"> Email Id</strong></label>
              <input type="email" placeholder="Email Id" name="email" value="<?php echo e(old('email')); ?>"
                class="form-control">
              <span id="number-validate" class="red-text"></span>
              <?php if($errors->has('email')): ?>
              <span class="red-text">
                <?php echo $errors->first('email', ':message'); ?>
              </span>
              <?php endif; ?>
            </div>
          </div>
          <div class="col-md-12 pt-2">
            <div class=" text-message-box">
              <label for="message"><strong style="color:#323232"> Message </strong></label>
              <textarea name="message" id="message" placeholder="Write a Message"
                class="form-control "><?php echo e(old('message')); ?></textarea>
              <span id="number-validate" class="red-text"></span>
              <?php if($errors->has('message')): ?>
              <span class="red-text">
                <?php echo $errors->first('message', ':message'); ?>
              </span>
              <?php endif; ?>
            </div>
          </div>
          <div class="col-md-12 py-3 captcha_set" style="text-align: left;">
            <?php echo NoCaptcha::renderJs(); ?>

            <?php echo NoCaptcha::display(); ?>


            <?php if($errors->has('g-recaptcha-response')): ?>
            <span class="help-block">
              <span class="red-text"><?php echo e($errors->first('g-recaptcha-response')); ?></span>
            </span>
            <?php endif; ?>
          </div>
        </div>
          <div class="d-flex justify-content-center" style="display: flex; justify-content:center;">
            <button type="submit" id="submitButton" class="btn formSubmit eduact-btn__curve_button" style="background-color: #243772; color:#fff;"><span
                class="eduact-btn__curve"></span>Submit<i class="icon-arrow"></i></button>
          </div>

        
      </form>
      <?php if(Session::has('success_message')): ?>
      <script>
        { Session::get('success_message') }}");
      </script>
      <?php endif; ?>
    </div>
</section>
<script>
    function addvalidateMobileNumber(number) {
        var mobileNumberPattern = /^\d*$/;
        var validationMessage = document.getElementById("validation-message");
  
        if (mobileNumberPattern.test(number)) {
            validationMessage.textContent = "";
        } else {
            validationMessage.textContent = "Please enter only numbers.";
        }
    }
  </script>
  <script>
    $(document).ready(function() {
  
        $("#regForm").validate({
            errorClass: "error",
            rules: {
                full_name: {
                    required: true,
                    spcenotallow: true,
                },
                email: {
                    required: true,
                    email: true,
                },
                mobile_number: {
                    required: true,
                    spcenotallow: true,
                },
                subject: {
                    required: true,
                },
                message: {
                    required: true,
                    spcenotallow: true,
                },
            },
            messages: {
                full_name: {
                    required: "Enter Full Name",
                    spcenotallow: "Enter Some Text",
                },
                email: {
                    required: "Enter Email Id",
                    spcenotallow: "Enter Some Text",
                },
                mobile_number: {
                    required: "Enter Mobile Number",
                    pattern: "Invalid Mobile Number",
                    remote: "This mobile number already exists.",
                    spcenotallow: "Enter Some Text",
                },
                subject: {
                    required: "Enter Company Name",
                },
                message: {
                    required: "Enter Message",
                },
            },
            highlight: function(element, errorClass) {
                $(element).removeClass(errorClass);
            },
            submitHandler: function(form) {
                // Check if reCAPTCHA challenge is completed
                if (grecaptcha.getResponse() === "") {
                    alert("Please complete the reCAPTCHA challenge.");
                } else {
                    // Proceed with form submission
                    form.submit();
                }
            }
        });
  
        $("input#document_file").hide();
  
    });
  
    $.extend($.validator.methods, {
        spcenotallow: function(b, c, d) {
            if (!this.depend(d, c)) return "dependency-mismatch";
            if ("select" === c.nodeName.toLowerCase()) {
                var e = a(c).val();
                return e && e.length > 0
            }
            return this.checkable(c) ? this.getLength(b, c) > 0 : b.trim().length > 0
        }
    });
  </script>
  
  <script>
    function dismissAlert(alertId) {
        var alertElement = document.getElementById(alertId);
        if (alertElement) {
            setTimeout(function() {
                alertElement.style.display = "none";
            }, 2000); // 2000 milliseconds = 2 seconds
        }
    }
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/website/pages/contactus.blade.php ENDPATH**/ ?>