<style>
    .form-control {
        border: 2px solid #ced4da;
        border-radius: 4px;
    }

    .error {
        color: red;
    }

    .no-print {
        display: none !important;
    }

    body {
        font-size: 12px;
    }

    .selfProfile {
        float: left;
        width: 50%;
    }

    .imgLogo {
        float: left;
        width: 30%;
    }

    .profile {
        /* float: right; */
        /* width: 70%; */
    }

    .data {
        float: right;
        width: 50%;
    }

    .bordersBottom {
        border-top: 1px solid black;
        border-left: 1px solid black;
        border-right: 1px solid black;
    }

    .borders {
        border: 1px solid black;
    }

    .no-border {
        border: none !important;
    }

    .invoice-payments {
        float: left;
        width: 60%;
    }

    .tops {
        margin-top: -63px;
    }

    table th,
    table td {
        border: 1px solid black;
        padding: 8px;
        /* Optional: add padding for better readability */
    }

    table th {
        background-color: #f2f2f2;
        /* Optional: add background color for table header */
    }

    /* table tr td {
                                border: 1px solid red;
                            } */
</style>


<div class="data-table-area mg-tb-15">
    <div class="container-fluid">
        <div class="row">

            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sparkline13-list">
                    <div class="row">
                        <div class="col-sm-12 col-lg-12 col-xl-12 m-b-20">

                            <table class="table table-striped table-hover" style="margin:0px;">
                                <thead>
                                    <tr
                                        style="border-width: 1px 1px 0px 1px; border-style: solid; border-color: black;">
                                        <td>
                                            <div class="row">
                                                <div class="col-lg-2 col-md-2 col-sm-2"
                                                    style="display: flex; justify-content: center; align-items: center;">
                                                    <img class="main-logo"
                                                        src="<?php echo e(Config::get('DocumentConstant.ORGANIZATION_VIEW') . $getOrganizationData->image); ?>"
                                                        alt="<?php echo e(strip_tags($getOrganizationData['company_name'])); ?> Image"
                                                        style="background-color: #175CA2" alt="">
                                                </div>
                                                <div class="col-lg-8 col-md-8 col-sm-8">
                                                    <div
                                                        style="display: flex;justify-content: center;align-items: center;">
                                                        <h4><?php echo e($getOrganizationData->company_name); ?></h4>
                                                    </div>
                                                    <div
                                                        style="display: flex;justify-content: center;align-items: center;">
                                                        <p><?php echo e($getOrganizationData->address); ?>,
                                                            <?php echo e($getOrganizationData->mobile_number); ?>,
                                                            <?php echo e($getOrganizationData->email); ?></p>
                                                    </div>
                                                </div>
                                                <div class="col-lg-2 col-md-2 col-sm-2">
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </thead>
                            </table>
                            <table class="table table-striped table-hover" style="margin:0px;">
                                <thead>
                                    <tr style="border-width: 0px; border-style: solid; border-color: black;">
                                        <td
                                            style="padding: 5px; align-items: center; display: flex; justify-content: center;">
                                            <div style="display: flex; justify-content: center;">
                                                
                                            </div><br>
                                        </td>
                                    </tr>
                                </thead>
                            </table>
                            <table class="table table-striped table-hover" style="margin:0px;">
                                <thead>
                                    <tr style="border-width: 0px; border-style: solid; border-color: black;">
                                        <td>
                                            <div class="row">
                                                <div class="col-md-6 selfProfile asdf">
                                                    <div class="row">
                                                        <div class="col-md-12 profile">
                                                            <ul class="list-unstyled">
                                                                <h4><?php echo e($purchaseOrder->vendor_company_name); ?></h4>
                                                                <li><?php echo e($purchaseOrder->vendor_address); ?></li>
                                                                <li><?php echo e($purchaseOrder->gst_no); ?></li>
                                                                
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <br>
                                                    <div class="row">
                                                        <div class="col-md-12">
                                                            <ul class="list-unstyled">
                                                                <li>Name : <?php echo e($purchaseOrder->vendor_name); ?></li>
                                                                <li>GST Number: <?php echo e($purchaseOrder->gst_no); ?>

                                                                </li>
                                                                
                                                                <li>Mobile No.:
                                                                    <?php echo e($purchaseOrder->phone_number); ?></li>
                                                                <li>Email: <a href="javascript:void(0)"><?php echo e($purchaseOrder->vendor_email); ?></a>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-6 data">
                                                    <div class="row">
                                                        <div class="col-md-6 selfProfile">
                                                            <ul class="list-unstyled">
                                                                <li><strong>P.O. No. :
                                                                        <?php echo e($purchaseOrder->purchase_orders_id); ?></strong>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                        <div class="col-md-6 data">
                                                            <ul class="list-unstyled">
                                                                <li><strong>Date:
                                                                        <?php echo e($purchaseOrder->created_at); ?></strong>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <br>
                                                    <div class="row">
                                                        <div class="col-md-6 selfProfile">
                                                            <ul class="list-unstyled">
                                                                <li>Quote Ref No.: <?php echo e($purchaseOrder->quote_no); ?></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                    <br>
                                                    <div class="row">
                                                        <div class="col-md-6 selfProfile">
                                                            <ul class="list-unstyled">
                                                                <li>Payment Terms:
                                                                    <?php echo e($purchaseOrder->payment_terms); ?> DAYS
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>


                                                    <br>
                                                </div>
                                            </div>
                                            <p style="margin: 0px; padding:10px 0px;"><b>Dear Sir, Please arrange to
                                                    supply following Material
                                                    as per quantity, specification and schedule
                                                    mentioned below</b></p>
                                        </td>

                                    </tr>
                                </thead>
                            </table>

                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr style="border:1px solid black;">
                                        <th>Sr. No.</th>
                                        <th class="col-sm-2">Part No.</th>
                                        <th class="col-md-2" colspan="2">Description</th>
                                        <th class="col-md-2">Due Date</th>
                                        <th class="col-md-2">Quantity</th>
                                        <th class="col-md-2">Rate</th>
                                        <th>Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $purchaseOrderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($item->part_no_id); ?></td>
                                        <td class="d-none d-sm-table-cell " colspan="2"
                                            style="max-width: 150px !important; overflow-wrap: break-word; word-wrap: break-word; word-break: break-all;">
                                            <?php echo e($item->description); ?></td>
                                        <td><?php echo e($item->due_date); ?></td>
                                        <td><?php echo e($item->quantity); ?> <?php echo e($item->unit); ?></td>
                                        <td><?php echo e($item->rate); ?></td>
                                        <td class="text-right">
                                            <?php echo e($item->amount); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot style="border:1px solid black;">
                                    <tr>
                                        <td class="no-border" colspan="3">
                                            <strong>Terms & Condition :-<?php echo e($getOrganizationData->terms_condition); ?></strong>
                                        </td>
                                        <td class="no-border" colspan="3"></td>
                                        <td>Sub Total</td>
                                        <td class="text-right">
                                            <?php echo e($purchaseOrderDetails->sum('amount')); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="no-border" colspan="3">
                                            <strong>Remark :-</strong>
                                        </td>
                                        <td class="no-border" colspan="3"></td>
                                        <td>Discount <?php echo e($purchaseOrder->discount); ?>

                                            %</td>
                                        <td class="text-right">
                                            <?php echo e($purchaseOrderDetails->sum('amount') -
                                            $purchaseOrderDetails->sum('amount') * ($purchaseOrder->discount / 100)); ?>

                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="no-border" colspan="6"></td>
                                        <td>Freight</td>
                                        <td class="text-right">
                                            0.00
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="no-border" colspan="6"></td>
                                        <td><?php echo e($purchaseOrder->tax_type); ?> <?php echo e($purchaseOrder->tax_id); ?> %</td>
                                        <td class="text-right">
                                            <?php echo e(($purchaseOrderDetails->sum('amount') -
                                            $purchaseOrderDetails->sum('amount') * ($purchaseOrder->discount / 100)) *
                                            (1 + ($purchaseOrder->tax_id / 100))); ?>

                                        </td>
                                    </tr>
                                    


                                    <tr>
                                        <td class="no-border" colspan="6"></td>
                                        <td>NIL GST</td>
                                        <td class="text-right">
                                            0.00
                                        </td>
                                    </tr>
                                    <tr style="border-bottom: 1px solid black">
                                        <td class="no-border" colspan="3">
                                            <strong>transport/Dispatch :-</strong>
                                        </td>
                                        <td class="no-border" colspan="3"></td>
                                        <td><strong> Net Total</strong></td>
                                        <td class="text-right">
                                            <strong>
                                                <?php echo e($purchaseOrderDetails->sum('amount') -
                                                $purchaseOrderDetails->sum('amount') * ($purchaseOrder->discount / 100)
                                                + ($purchaseOrderDetails->sum('amount') -
                                                $purchaseOrderDetails->sum('amount') * ($purchaseOrder->discount / 100))
                                                * 0.09 * 2); ?></strong>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="8" class="no-border">
                                            Delivery AS EPR ATTACHED DELIVERY SHEDULE</td>
                                    </tr>
                                    <tr>
                                        <td colspan="8" class="no-border">
                                            <div style="float: right;"><strong>For. SHREERAG
                                                ENGINEERING & AUTO PVT. LTD.</strong></div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td class="no-border" colspan="2">
                                            <strong>Prepared By</strong>
                                        </td>
                                        <td class="no-border" colspan="2">( Finance Signatory )</td>
                                        <td class="no-border" colspan="2">( Purchase Signatory )</td>
                                        <td class="no-border" colspan="1">( Authorized Signatory )</td>
                                    </tr>
                                </tfoot>


                            </table>
                        </div>

                    </div>
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="background-color: #fff; border:1px solid black;">
                        <div class="" style="padding: 20px 10px 20px 10px;">
                          <h3><?php echo e($getAllRulesAndRegulations->title); ?></h3>
                          <p><?php echo e($getAllRulesAndRegulations->description); ?></p>
                        </div>
                      </div>

                    <a ><button data-toggle="tooltip" onclick="printInvoice()"
                        title="Accept Purchase Order" class="pd-setting-ed" style="margin-top: 20px;">Print</button></a>
                </div>

                

               
                <script>
                    function printInvoice() {
                        window.print();
                    }
                </script>

            </div>
        </div><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/organizations/common-pages/purchase-order-view.blade.php ENDPATH**/ ?>