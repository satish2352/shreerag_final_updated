
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('organizations.common-pages.purchase-order-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="" style="margin-bottom: 70px;">
        <a href="<?php echo e(route('accept-purchase-order', ['purchase_order_id' => $purchase_order_id, 'business_id' => $business_id])); ?>"><button data-toggle="tooltip"
                title="Accept Purchase Order" class="pd-setting-ed">Accept</button></a> &nbsp;
        &nbsp; &nbsp;
    </div>


    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/organizations/business/purchase-order/purchase-order-details.blade.php ENDPATH**/ ?>