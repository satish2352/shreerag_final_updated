
<?php $__env->startSection('content'); ?>
<style>
    label {
        margin-top: 10px;
    }
    label.error {
        color: red; /* Change 'red' to your desired text color */
        font-size: 12px; /* Adjust font size if needed */
        /* Add any other styling as per your design */
    }

    .red-text{
        color: red !important;
    }
    .password-toggle {
            cursor: pointer;
            position: absolute;
            top: 65%;
            right: 20px;
            transform: translateY(-50%);
        }

        .fa-eye-slash {
            /* display: none; */
        }
</style>
<div class="container-fluid">
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="sparkline12-list" style="padding-bottom: 100px">
            <div class="sparkline12-hd">
                <div class="main-sparkline12-hd">
                    <center><h1>Add Employee Data</h1></center>
                </div>
            </div>
            <div class="sparkline12-graph">
                <div class="basic-login-form-ad">
                    <div class="row">
     



                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="all-form-element-inner">


                                    <form class="forms-sample" id="regForm" name="regForm" method="post" role="form"
                                    action="<?php echo e(route('add-users')); ?>" enctype="multipart/form-data">
                                    <div class="row">
                                        <input type="hidden" name="_token" id="csrf-token" value="<?php echo e(Session::token()); ?>" />
    
                                        
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="u_email">Email ID</label>&nbsp<span class="red-text">*</span>
                                                <input type="text" class="form-control" name="u_email" id="u_email"
                                                    placeholder="" value="<?php echo e(old('u_email')); ?>">
                                                <?php if($errors->has('u_email')): ?>
                                                    <span class="red-text"><?php echo $errors->first('u_email', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="role_id">Department</label>&nbsp<span class="red-text">*</span>
                                                <select class="form-control" id="role_id" name="role_id"
                                                    onchange="myFunction(this.value)">
                                                    <option value="">Select Department</option>
                                                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(old('role_id') == $role['id']): ?>
                                                            <option value="<?php echo e($role['id']); ?>" selected>
                                                                <?php echo e($role['role_name']); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($role['id']); ?>"><?php echo e($role['role_name']); ?>

                                                            </option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <?php if($errors->has('role_id')): ?>
                                                    <span class="red-text"><?php echo $errors->first('role_id', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="u_password">Password</label>&nbsp<span class="red-text">*</span>
                                                <input type="password" class="password form-control" name="u_password"
                                                    id="u_password" placeholder="" value="<?php echo e(old('u_password')); ?>">
                                                <span id="togglePassword" class="togglePpassword password-toggle"
                                                    onclick="togglePasswordVisibility()">
                                                    <i class="fa fa-eye-slash"></i>
                                                </span>
                                                <?php if($errors->has('u_password')): ?>
                                                    <span class="red-text"><?php echo $errors->first('u_password', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="password_confirmation">Confirm Password</label>&nbsp<span
                                                    class="red-text">*</span>
                                                <input type="password" class="password_confirmation form-control"
                                                    id="password_confirmation" name="password_confirmation"
                                                    value="<?php echo e(old('password_confirmation')); ?>">
                                                <span id="toggleConfirmPassword" class=" toggleConfirmPpassword password-toggle"
                                                    onclick="toggleConfirmPasswordVisibility()">
                                                    <i class="fa fa-eye-slash"></i>
                                                </span>
                                                <span id="password-error" class="error-message red-text"></span>
                                                <?php if($errors->has('password_confirmation')): ?>
                                                    <span class="red-text"><?php echo $errors->first('password_confirmation', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="f_name">First Name</label>&nbsp<span class="red-text">*</span>
                                                <input type="text" class="form-control" name="f_name" id="f_name"
                                                    placeholder="" value="<?php echo e(old('f_name')); ?>"
                                                    oninput="this.value = this.value.replace(/[^a-zA-Z\s.]/g, '').replace(/(\..*)\./g, '$1');">
                                                <?php if($errors->has('f_name')): ?>
                                                    <span class="red-text"><?php echo $errors->first('f_name', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
    
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="m_name">Middle Name</label>&nbsp<span class="red-text">*</span>
                                                <input type="text" class="form-control" name="m_name" id="m_name"
                                                    placeholder="" value="<?php echo e(old('m_name')); ?>"
                                                    oninput="this.value = this.value.replace(/[^a-zA-Z\s.]/g, '').replace(/(\..*)\./g, '$1');">
                                                <?php if($errors->has('m_name')): ?>
                                                    <span class="red-text"><?php echo $errors->first('m_name', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
    
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="l_name">Last Name</label>&nbsp<span class="red-text">*</span>
                                                <input type="text" class="form-control" name="l_name" id="l_name"
                                                    placeholder="" value="<?php echo e(old('l_name')); ?>"
                                                    oninput="this.value = this.value.replace(/[^a-zA-Z\s.]/g, '').replace(/(\..*)\./g, '$1');">
                                                <?php if($errors->has('l_name')): ?>
                                                    <span class="red-text"><?php echo $errors->first('l_name', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="number">Mobile Number</label>&nbsp<span
                                                    class="red-text">*</span>
                                                <input type="text" class="form-control" name="number" id="number"
                                                    pattern="[789]{1}[0-9]{9}"
                                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');"
                                                    maxlength="10" minlength="10" placeholder=""
                                                    value="<?php echo e(old('number')); ?>"
                                                    onkeyup="addvalidateMobileNumber(this.value)">
                                                <span id="validation-message" class="red-text"></span>
                                                <?php if($errors->has('number')): ?>
                                                    <span class="red-text"><?php echo $errors->first('number', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="designation">Designation</label>&nbsp<span
                                                    class="red-text">*</span>
                                                <input type="text" class="form-control" name="designation"
                                                    id="designation" placeholder="" value="<?php echo e(old('designation')); ?>"
                                                    oninput="this.value = this.value.replace(/[^a-zA-Z\s.]/g, '').replace(/(\..*)\./g, '$1');">
                                                <?php if($errors->has('number')): ?>
                                                    <span class="red-text"><?php echo $errors->first('designation', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="address">Address</label>&nbsp<span class="red-text">*</span>
                                                <input type="text" class="form-control" name="address" id="address"
                                                    placeholder="" value="<?php echo e(old('address')); ?>">
                                                <?php if($errors->has('address')): ?>
                                                    <span class="red-text"><?php echo $errors->first('address', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="state">State</label>&nbsp<span class="red-text">*</span>
                                                <select class="form-control" id="state" name="state">
                                                    <option>Select State</option>
                                                    <?php $__currentLoopData = $dynamic_state; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(old('state') == $state['location_id']): ?>
                                                            <option value="<?php echo e($state['location_id']); ?>" selected>
                                                                <?php echo e($state['name']); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($state['location_id']); ?>">
                                                                <?php echo e($state['name']); ?>

                                                            </option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="city">City</label>&nbsp<span class="red-text">*</span>
                                                <select class="form-control" name="city" id="city">
                                                    <option value="">Select City</option>
                                                </select>
                                                <?php if($errors->has('city')): ?>
                                                    <span class="red-text"><?php echo $errors->first('city', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="form-group">
                                                <label for="pincode">Pincode</label>&nbsp<span class="red-text">*</span>
                                                <input type="text" class="form-control" name="pincode" id="pincode"
                                                    placeholder="" value="<?php echo e(old('pincode')); ?>"
                                                    onkeyup="addvalidatePincode(this.value)">
                                                <span id="validation-message-pincode" class="red-text"></span>
                                                <?php if($errors->has('pincode')): ?>
                                                    <span class="red-text"><?php echo $errors->first('pincode', ':message'); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="col-lg-12 col-md-12 col-sm-12 user_tbl">
                                            <div id="data_for_role">
                                            </div>
                                        </div>
                                        <br>
                                        <div class="col-lg-6 col-md-6 col-sm-6 mt-3">
                                            <div class="form-group form-check form-check-flat form-check-primary">
                                                <label class="form-check-label">
                                                    <input type="checkbox" class="form-check-input" name="is_active"
                                                        id="is_active" value="y" data-parsley-multiple="is_active"
                                                        <?php echo e(old('is_active') ? 'checked' : ''); ?>>
                                                    Is Active
                                                    <i class="input-helper"></i><i class="input-helper"></i></label>
                                            </div>
                                        </div>
    
                                        <div class="col-md-12 col-sm-12 text-center">
                                            <button type="submit" class="btn btn-sm btn-success" id="submitButton" >
                                                Save &amp; Submit
                                            </button>
                                            
                                            <span><a href="<?php echo e(route('list-users')); ?>"
                                                    class="btn btn-sm btn-primary ">Back</a></span>
                                        </div>
                                    </div>
                                </form>

                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script> <!-- Include SweetAlert library -->
<script type="text/javascript">
    function submitRegister() {
        document.getElementById("frm_register").submit();
    }
</script>
<script>
    function addvalidateMobileNumber(number) {
        var mobileNumberPattern = /^\d*$/;
        var validationMessage = document.getElementById("validation-message");

        if (mobileNumberPattern.test(number)) {
            validationMessage.textContent = "";
        } else {
            validationMessage.textContent = "Please enter only numbers.";
        }
    }
</script>
<script>
    function addvalidatePincode(number) {
        var pincodePattern = /^\d*$/;
        var validationMessage = document.getElementById("validation-message-pincode");

        if (pincodePattern.test(number)) {
            validationMessage.textContent = "";
        } else {
            validationMessage.textContent = "Please enter only numbers.";
        }
    }
</script>


<script>
    $(document).ready(function() {

        $('#state').change(function(e) {
            e.preventDefault();
            var stateId = $('#state').val();
            // console.log(stateId);
            $('#city').html('<option value="">Select City</option>');

            if (stateId !== '') {
                $.ajax({
                    url: '<?php echo e(route('cities')); ?>',
                    type: 'GET',
                    data: {
                        stateId: stateId
                    },
                    // headers: {
                    //     'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    // },
                    success: function(response) {
                        console.log(response);
                        if (response.city.length > 0) {
                            $.each(response.city, function(index, city) {
                                $('#city').append('<option value="' + city
                                    .location_id +
                                    '">' + city.name + '</option>');
                            });
                        }
                    }
                });
            }
        });
    });
</script>

<script>
    function togglePasswordVisibility() {
        var passwordInput = document.getElementsByClassName("password")[0];
        var toggleIcon = document.querySelector(".togglePpassword i");

        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            toggleIcon.classList.remove("fa-eye-slash");
            toggleIcon.classList.add("fa-eye");
        } else {
            passwordInput.type = "password";
            toggleIcon.classList.remove("fa-eye");
            toggleIcon.classList.add("fa-eye-slash");
        }
    }
</script>
<script>
    function toggleConfirmPasswordVisibility() {
        var passwordInput = document.getElementsByClassName("password_confirmation")[0];

        var toggleIcon = document.querySelector(".toggleConfirmPpassword i");

        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            toggleIcon.classList.remove("fa-eye-slash");
            toggleIcon.classList.add("fa-eye");
        } else {
            passwordInput.type = "password";
            toggleIcon.classList.remove("fa-eye");
            toggleIcon.classList.add("fa-eye-slash");
        }
    }
</script>
<script>
    $(document).ready(function() {
        // Function to check if all input fields are filled with valid data
        function checkFormValidity() {
            const u_email = $('#u_email').val();
            const role_id = $('#role_id').val();
            const u_password = $('#u_password').val();
            const password_confirmation = $('#password_confirmation').val();
            const f_name = $('#f_name').val();
            const m_name = $('#m_name').val();
            const l_name = $('#l_name').val();
            const number = $('#number').val();
            const designation = $('#designation').val();
            const address = $('#address').val();
            const state = $('#state').val();
            const city = $('#city').val();
            // const user_profile = $('#user_profile').val();
            const pincode = $('#pincode').val();

            // Enable the submit button if all fields are valid
            if (u_email && role_id && u_password && password_confirmation && f_name && m_name && l_name &&
                number && designation && address && state && city &&  pincode) {
                $('#submitButton').prop('disabled', false);
            } else {
                $('#submitButton').prop('disabled', true);
            }
        }

        // Call the checkFormValidity function on input change
        // $('input,textarea, select, #user_profile').on('input change',
            // checkFormValidity);

            $.validator.addMethod("number", function(value, element) {
            return this.optional(element) || /^[0-9]{10}$/.test(value);
        }, "Please enter a valid 10-digit number.");

        $.validator.addMethod("u_email", function(value, element) {
            // Regular expression for email validation
            const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            return this.optional(element) || emailRegex.test(value);
        }, "Please enter a valid email address.");

        // Initialize the form validation
        $("#regForm").validate({
            rules: {
                u_email: {
                    required: true,
                //     remote: {
                //     url: '/web/check-email-exists',
                //     type: 'post',
                //     data: {
                //         u_email: function() {
                //             return $('#u_email').val();
                //         }
                //     }
                // },
                    u_email:true,
                },
                role_id: {
                    required: true,
                },
                u_password: {
                    required: true,
                },
                password_confirmation: {
                    required: true,
                },
                f_name: {
                    required: true,
                },
                m_name: {
                    required: true,
                },
                l_name: {
                    required: true,
                },
                number: {
                    required: true,
                    number:true,
                },
                designation: {
                    required: true,
                },
                address: {
                    required: true,
                },
                state: {
                    required: true,
                },
                city: {
                    required: true,
                },
                // user_profile: {
                //     required: true,
                // },
                pincode: {
                    required: true,
                },

            },
            messages: {
                u_email: {
                    required: "Please Enter the Eamil",
                    // remote: "This Email already exists."
                },
                role_id: {
                    required: "Please Select Role Name",
                },
                u_password: {
                    required: "Please Enter the Password",
                },
                password_confirmation: {
                    required: "Please Enter the Confirmation Password",
                },
                f_name: {
                    required: "Please Enter the First Name",
                },
                m_name: {
                    required: "Please Enter the Middle Name",
                },
                l_name: {
                    required: "Please Enter the Last Name",
                },
                number: {
                    required: "Please Enter the Number",
                },
                designation: {
                    required: "Please Enter the Designation",
                },
                address: {
                    required: "Please Enter the Address",
                },

                state: {
                    required: "Please Select State",
                },
                city: {
                    required: "Please Select State",
                },
                // user_profile: {
                //     required: "Upload Media File",
                //     accept: "Only png, jpeg, and jpg image files are allowed.", // Update the error message for the accept rule
                // },
                pincode: {
                    required: "Please Enter the Pincode",
                },
            },

        });
    });
</script>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/organizations/hr/employees/add-employees.blade.php ENDPATH**/ ?>