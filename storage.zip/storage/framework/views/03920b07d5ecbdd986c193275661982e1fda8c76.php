
<?php $__env->startSection('content'); ?>
    <style>
        label {
            margin-top: 10px;
        }

        label.error {
            color: red;
            /* Change 'red' to your desired text color */
            font-size: 12px;
            /* Adjust font size if needed */
            /* Add any other styling as per your design */
        }
    </style>
 
 <div class="container-fluid">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="sparkline12-list">
                <div class="sparkline12-hd">
                    <div class="main-sparkline12-hd">
                        <center>
                            <h1>Edit GRN Data</h1>
                        </center>
                    </div>
                </div>
                <div class="sparkline12-graph">
                    <div class="basic-login-form-ad">
                        <div class="row">
                            <?php if(session('msg')): ?>
                                <div class="alert alert-<?php echo e(session('status')); ?>">
                                    <?php echo e(session('msg')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <?php if(Session::has('status')): ?>
                                    <div class="col-md-12">
                                        <div class="alert alert-<?php echo e(Session::get('status')); ?> alert-dismissible"
                                            role="alert">
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <strong><?php echo e(ucfirst(Session::get('status'))); ?>!</strong>
                                            <?php echo e(Session::get('msg')); ?>

                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="all-form-element-inner">
                                        <form action="<?php echo e(route('update-grn', 
                                       )); ?>"
                                            method="POST" id="editDesignsForm" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                           
                                            <!-- <a
                                             
                                            class="btn btn-sm btn-primary ml-3"> <button type="button" name="add" id="add" class="btn btn-success">Add More</button></a> -->

                                            <div class="container-fluid">
                                                <!-- <?php if($errors->any()): ?>
                                                    <div class="alert alert-danger">
                                                        <ul>
                                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><?php echo e($error); ?></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </div>
                                                <?php endif; ?> -->

                                                <?php $__currentLoopData = $editData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $editDataNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($key == 0): ?>    
                                                    <div class="form-group-inner">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <label for="grn_date">GRN Date:</label>
                                                                <input type="date" class="form-control" id="grn_date"
                                                                    name="grn_date" 
                                                                    value="<?php echo e($editDataNew->grn_date); ?>"
                                                                    placeholder="Enter GRN Date">
                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <label for="purchase_id">PO No.:</label>
                                                                <input type="text" class="form-control" id="purchase_id"
                                                                    name="purchase_id" 
                                                                    value="<?php echo e($editDataNew->purchase_id); ?>"
                                                                    placeholder="Enter Purchase No.">
                                                            </div>
                                                        </div>

                                                        <div class="row">    
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <label for="po_date">PO Date :</label>
                                                                <input type="date" class="form-control" id="po_date"
                                                                    name="po_date" 
                                                                    value="<?php echo e($editDataNew->po_date); ?>"
                                                                    placeholder="Enter PO Date">
                                                            </div>                                               

                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <label for="invoice_no">Invoice No.:</label>
                                                                <input type="text" class="form-control" id="invoice_no"
                                                                    name="invoice_no" 
                                                                    value="<?php echo e($editDataNew->invoice_no); ?>"
                                                                    placeholder="Enter Invoice No">
                                                            </div>
                                                        </div>    

                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <label for="invoice_date">Invoice Date:</label>
                                                                <input type="date" class="form-control" id="invoice_date"
                                                                    name="invoice_date" 
                                                                    value="<?php echo e($editDataNew->invoice_date); ?>"
                                                                    placeholder="Enter Invoice Date">
                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                    <label for="image">Image:</label>
                                                                    <input type="file" class="form-control"
                                                                        accept="image/*" id="image" name="image">
                                                                    <div id="oldImageDisplay">
                                                                        <?php if(isset($editDataNew->image)): ?>
                                                                            <b>Image Preview: </b>
                                                                            <img src="<?php echo e(Config::get('FileConstant.GRN_VIEW') . $editDataNew->image); ?>"
                                                                                alt="Old Image" style="max-width: 100px;">
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div id="selectedImageDisplay" style="display: none;">
                                                                        <b>Image Preview: </b>
                                                                        <img src="" alt="Selected Image"
                                                                            style="max-width: 100px;">
                                                                    </div>
                                                            </div>
                                                     </div>
                                                    </div> 
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <div style="margin-top:30px;"> 
                                                    <table class="table table-bordered" id="dynamicTable">
                                                        <tr>
                                                            <th>Description</th>
                                                            <th>QC Check</th>
                                                            <th>Chalan Quantity</th>
                                                            <th>Actual Quantity</th>
                                                            <th>Accepted Quantity</th>
                                                            <th>Rejected Quantity</th>
                                                            <th>Action</th>
                                                        </tr>
                                                        <?php $__currentLoopData = $editData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $editDataNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        
                                                            <tr>                                                                                                                      
                                                                <td>
                                                                    <input type="text"
                                                                        name="description_<?php echo e($key); ?>"
                                                                        value="<?php echo e($editDataNew->description); ?>"
                                                                        placeholder="Enter Description"
                                                                        class="form-control" />
                                                                </td>
                                                                        
                                                                <td>
                                                                    <input type="text"
                                                                        name="qc_check_remark_<?php echo e($key); ?>"
                                                                        value="<?php echo e($editDataNew->qc_check_remark); ?>"
                                                                        placeholder="Enter QC Check"
                                                                         class="form-control" />
                                                                </td>

                                                                <td>
                                                                    <input type="text"
                                                                        name="chalan_quantity_<?php echo e($key); ?>"
                                                                        value="<?php echo e($editDataNew->chalan_quantity); ?>"
                                                                        placeholder="Enter Chalan Qty"
                                                                        class="form-control" />
                                                                </td>

                                                                <td>
                                                                    <input type="text"
                                                                        name="actual_quantity_<?php echo e($key); ?>"
                                                                        value="<?php echo e($editDataNew->actual_quantity); ?>"
                                                                        placeholder="Enter Actual Qty"
                                                                        class="form-control" />
                                                                </td>

                                                                <td>
                                                                    <input type="text"
                                                                        name="accepted_quantity_<?php echo e($key); ?>"
                                                                        value="<?php echo e($editDataNew->accepted_quantity); ?>"
                                                                        placeholder="Enter Accepted Qty"
                                                                        class="form-control" />
                                                                </td>

                                                                <td>
                                                                    <input type="text"
                                                                        name="rejected_quantity_<?php echo e($key); ?>"
                                                                        value="<?php echo e($editDataNew->rejected_quantity); ?>"
                                                                        placeholder="Enter Rejected Qty"
                                                                        class="form-control" />
                                                                </td>

                                                                <td>
                                                                    <a data-id="<?php echo e($editDataNew->id); ?>"
                                                                        class="delete-btn btn btn-danger m-1"
                                                                        title="Delete Tender"><i
                                                                            class="fas fa-archive"></i></a>                
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </table>
                                                </div>    

                                                <div class="row">
                                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                        <label for="remark">Remark:</label>
                                                        <input type="text" class="form-control" id="remark"
                                                            name="remark" 
                                                            value="<?php echo e($editDataNew->remark); ?>"
                                                            placeholder="Enter Remark">
                                                    </div>

                                                    <!-- <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                                        <label for="remark">Remark:</label>
                                                            <textarea class="form-control" rows="3" type="text" class="form-control" id="remark"
                                                            name="remark" placeholder="Enter Remark"></textarea>
                                                    </div>                                                 -->
                                                </div>

                                                
                                                <div class="login-btn-inner">
                                                    <div class="row">
                                                        <div class="col-lg-5"></div>
                                                        <div class="col-lg-7">
                                                            <div class="login-horizental cancel-wp pull-left">
                                                                <a href="<?php echo e(route('list-grn')); ?>"
                                                                    class="btn btn-white"
                                                                    style="margin-bottom:50px">Cancel</a>
                                                                <button class="btn btn-sm btn-primary login-submit-cs"
                                                                    type="submit" style="margin-bottom:50px">Update Data</button>
                                                               
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


    <form method="POST" action="<?php echo e(route('delete-addmore')); ?>" id="deleteform">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="delete_id" id="delete_id" value="">
    </form>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
 
<script>
    // $(document).ready(function() {
    //     var i = <?php echo count($editData); ?>; // Initialize i with the number of existing rows

    //     $("#add").click(function() {
    //         ++i;

    //         $("#dynamicTable").append(
    //             '<tr><td><input type="text" name="design_name_' + i + '" placeholder="Enter Product Name" class="form-control" /></td><td><input type="text" name="product_quantity_' + i + '" placeholder="Enter Product Quantity" class="form-control" /></td><td><input type="text" name="product_size_' + i + '" placeholder="Enter Product Price" class="form-control" /></td><td><input type="text" name="product_unit_' + i + '" placeholder="Enter Product Unit" class="form-control" /></td><td><button type="button" class="btn btn-danger remove-tr">Remove</button></td></tr>'
    //         );
    //     });

    //     $(document).on("click", ".remove-tr", function() {
    //         $(this).parents("tr").remove();
    //     });

    //     // Hide the "Add More" button initially if needed
    //     // $("#add").hide();
    // });

    $(document).ready(function() {
    var i = <?php echo count($editData); ?>; // Initialize i with the number of existing rows

    $("#add").click(function() {
        ++i;

        $("#dynamicTable").append(
            '<tr><td><input type="text" name="design_name_' + i + '" placeholder="Enter Product Name" class="form-control" /></td><td><input type="text" name="product_quantity_' + i + '" placeholder="Enter Product Quantity" class="form-control" /></td><td><input type="text" name="product_size_' + i + '" placeholder="Enter Product Price" class="form-control" /></td><td><input type="text" name="product_unit_' + i + '][product_unit_]" placeholder="Enter Product Unit" class="form-control" /></td><td><a class="delete-btn btn btn-danger m-1 remove-tr" title="Delete Tender"><i class="fas fa-archive"></i></a></td></tr>'
        );
    });

    $(document).on("click", ".remove-tr", function() {
        $(this).parents("tr").remove();
    });

    // Hide the "Add More" button initially if needed
    // $("#add").hide();
});

</script>
<script>
    $('.delete-btn').click(function(e) {

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $("#delete_id").val($(this).attr("data-id"));
                $("#deleteform").submit();
            }
        })

    });
</script>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerang\resources\views/organizations/quality/grn/edit-grn.blade.php ENDPATH**/ ?>