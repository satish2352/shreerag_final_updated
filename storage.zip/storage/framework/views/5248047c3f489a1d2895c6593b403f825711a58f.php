
<?php $__env->startSection('content'); ?>
<style>
    .fixed-table-loading {
        display: none;
    }
    #table thead th {
        white-space: nowrap;
    }
    #table thead th {
        width: 300px !important;
        padding-right: 49px !important;
        padding-left: 20px !important;
    }
    .custom-datatable-overright table tbody tr td {
        padding-left: 19px !important;
        padding-right: 5px !important;
        font-size: 14px;
        text-align: left;
    }
</style>

<div class="data-table-area mg-tb-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sparkline13-list">
                    <div class="sparkline13-hd">
                        <div class="main-sparkline13-hd">
                            <h1>Approved Leaves  <span class="table-project-n">Data</span> Table</h1>
                            <div class="form-group-inner login-btn-inner row">
                                <div class="col-lg-10"></div>
                            </div>
                        </div>
                    </div>

                    <?php if(Session::get('status') == 'success'): ?>
                        <div class="alert alert-success alert-success-style1">
                            <button type="button" class="close sucess-op" data-dismiss="alert" aria-label="Close">
                                <span class="icon-sc-cl" aria-hidden="true">&times;</span>
                            </button>
                            <i class="fa fa-check adminpro-checked-pro admin-check-pro" aria-hidden="true"></i>
                            <p><strong>Success!</strong> <?php echo e(Session::get('msg')); ?></p>
                        </div>
                    <?php endif; ?>
                    <?php if(Session::get('status') == 'error'): ?>
                        <div class="alert alert-danger alert-mg-b alert-success-style4">
                            <button type="button" class="close sucess-op" data-dismiss="alert" aria-label="Close">
                                <span class="icon-sc-cl" aria-hidden="true">&times;</span>
                            </button>
                            <i class="fa fa-times adminpro-danger-error admin-check-pro" aria-hidden="true"></i>
                            <p><strong>Danger!</strong> <?php echo e(Session::get('msg')); ?></p>
                        </div>
                    <?php endif; ?>

                    <div class="sparkline13-graph">
                        <div class="datatable-dashv1-list custom-datatable-overright">
                            <div id="toolbar">
                                <select class="form-control">
                                    <option value="">Export Basic</option>
                                    <option value="all">Export All</option>
                                    <option value="selected">Export Selected</option>
                                </select>
                            </div>

                            <div class="table-responsive">
                                <table id="table" data-toggle="table" data-pagination="true" data-search="true"
                                    data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true"
                                    data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true"
                                    data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true"
                                    data-toolbar="#toolbar">
                                    <thead>
                                        <tr>
                                            <th data-field="id">ID</th>
                                            <th data-field="u_email" data-editable="true">Email</th>
                                            <th data-field="employee_id" data-editable="true">Employee Id</th>
                                            <th data-field="leave_start_date" data-editable="true">Leave Start Date</th>
                                            <th data-field="leave_end_date" data-editable="true">Leave End Date</th>
                                            <th data-field="leave_day" data-editable="true">Leave Day</th>
                                            <th data-field="leave_type_id" data-editable="true">Leave Type</th>
                                            <th data-field="leave_count" data-editable="true">Leave Count</th>
                                            <th data-field="reason" data-editable="true">Reason</th>
                                            <th data-field="action">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $getOutput; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($data->id); ?></td>
                                            <td><?php echo e(ucwords($data->employee_id)); ?>(<?php echo e(ucwords($data->f_name)); ?><?php echo e(ucwords($data->m_name)); ?><?php echo e(ucwords($data->l_name)); ?>)</td>
                                            <td><?php echo e(ucwords($data->u_email)); ?></td>
                                            <td><?php echo e(ucwords($data->leave_start_date)); ?></td>
                                            <td><?php echo e(ucwords($data->leave_end_date)); ?></td>
                                            <td> <?php if($data->leave_day == 'half_day'): ?>
                                                Half Day
                                              <?php elseif($data->leave_day == 'full_day'): ?>
                                             Full Day
                                              <?php else: ?>
                                                  Unknown Status
                                              <?php endif; ?></td>
                                              <td><?php echo e(ucwords($data->leave_type_name)); ?></td>
                                              <td><?php echo e(ucwords($data->leave_count)); ?></td>
                                            <td><?php echo e(ucwords($data->reason)); ?></td>
                                            <td>
                                                <div style="display: flex; align-items: center;">
                                                    
                                                    <button data-id="<?php echo e($data->id); ?>" data-action="notapprove" data-toggle="tooltip" title="Not Approve" class="notapprove-btn pd-setting-ed" style="color: red;
                                                        border: 1px solid;">
                                                        <i class="fa fa-times" aria-hidden="true"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<form method="POST" action="<?php echo e(url('/update-status')); ?>" id="activeform">
    <?php echo csrf_field(); ?>
    <input type="hidden" name="active_id" id="active_id" value="">
    <input type="hidden" name="action" id="action" value="">
</form>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    $(document).ready(function() {
        $('.approve-btn, .notapprove-btn').click(function(e) {
            var leaveId = $(this).data('id');
            var action = $(this).data('action');
            $("#active_id").val(leaveId);
            $("#action").val(action);
            $("#activeform").submit();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/organizations/hr/leaves/list-leaves-approved.blade.php ENDPATH**/ ?>