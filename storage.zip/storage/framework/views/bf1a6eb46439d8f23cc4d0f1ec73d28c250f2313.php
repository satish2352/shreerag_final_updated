<div class="left-sidebar-pro">
    <nav id="sidebar" class="">
        <div class="sidebar-header">
            <a href="<?php echo e(route('login')); ?>"><img class="main-logo"
                    src="<?php echo e(asset('website/assets/img/logo/LANSCAPE LOG.png')); ?>" alt=""></a>
            <strong><img src="<?php echo e(asset('img/logo/logo_updated.png')); ?>" alt=""></strong>
        </div>
        <div class="left-custom-menu-adp-wrap comment-scrollbar">
            <nav class="sidebar-nav left-sidebar-menu-pro">

                <ul class="metismenu" id="menu1">
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.SUPER')): ?>
                        <li
                            class="<?php echo e(Request::is('list-organizations', 'organizations-list-employees', 'list-departments', 'list-roles') ? 'active' : ''); ?>">
                            <a class="has-arrow" href="<?php echo e(route('list-organizations')); ?>" aria-expanded="false">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">Organizations</span>
                            </a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li class="nav-item <?php echo e(Request::is('list-organizations') ? 'active' : ''); ?>">
                                    <a title="Inbox" href="<?php echo e(route('list-organizations')); ?>">
                                        <i class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i>
                                        <span class="mini-sub-pro">List Organizations</span>
                                    </a>
                                </li>
                                <li class="nav-item <?php echo e(Request::is('organizations-list-employees') ? 'active' : ''); ?>">
                                    <a title="Inbox" href="<?php echo e(route('organizations-list-employees')); ?>">
                                        <i class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i>
                                        <span class="mini-sub-pro">List Employees</span>
                                    </a>
                                </li>
                                <li class="nav-item <?php echo e(Request::is('list-departments') ? 'active' : ''); ?>">
                                    <a title="Inbox" href="<?php echo e(route('list-departments')); ?>">
                                        <i class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i>
                                        <span class="mini-sub-pro">List Departments</span>
                                    </a>
                                </li>
                                <li class="nav-item <?php echo e(Request::is('list-roles') ? 'active' : ''); ?>">
                                    <a title="Inbox" href="<?php echo e(route('list-roles')); ?>">
                                        <i class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i>
                                        <span class="mini-sub-pro">List Roles</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>

                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.HIGHER_AUTHORITY')): ?>
                        <ul class="sidebar-menu" id="nav-accordion">
                            <li class="nav-item <?php echo e(request()->is('owner/organizations-list-employees') ? 'active' : ''); ?>">
                                <a title="Inbox" href="<?php echo e(route('organizations-list-employees')); ?>"><i
                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                        class="mini-sub-pro">Add Employees</span></a>
                            </li>
                            
                            <li class="nav-item <?php echo e(request()->is('owner/list-business') ? 'active' : ''); ?>">
                                <a title="Inbox" href="<?php echo e(route('list-business')); ?>"><i
                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                        class="mini-sub-pro">Business</span></a>
                            </li>
                            <li class="nav-item <?php echo e(request()->is('owner/list-forwarded-to-design') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('list-forwarded-to-design')); ?>" aria-expanded="false"><i
                                        class="fa big-icon fa-envelope icon-wrap"></i> <span
                                        class="mini-click-non">Business Sent For Design</span></a>
                            </li>
                            <li class="nav-item <?php echo e(request()->is('owner/list-design-uploaded-owner') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('list-design-uploaded-owner')); ?>" aria-expanded="false"><i
                                        class="fa big-icon fa-envelope icon-wrap"></i> <span
                                        class="mini-click-non">Design Received For Production</span></a>
                            </li>
                            <li class="nav-item <?php echo e(request()->is('owner/list-design-correction') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('list-design-correction')); ?>" aria-expanded="false"><i
                                        class="fa big-icon fa-envelope icon-wrap"></i> <span
                                        class="mini-click-non">Design Received For Design Correction</span></a>
                            </li>

                            <li class="nav-item <?php echo e(request()->is('owner/material-ask-by-prod-to-store') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('material-ask-by-prod-to-store')); ?>" aria-expanded="false"><i
                                        class="fa big-icon fa-envelope icon-wrap"></i> <span
                                        class="mini-click-non">Material Ask By Production To Store</span></a>
                            </li>

                            <li class="nav-item <?php echo e(request()->is('owner/material-ask-by-store-to-purchase') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('material-ask-by-store-to-purchase')); ?>" aria-expanded="false"><i
                                        class="fa big-icon fa-envelope icon-wrap"></i> <span
                                        class="mini-click-non">Purchase Material Ask By Store To Purchase</span></a>
                            </li>



                            <li class="nav-item <?php echo e(request()->is('owner/list-purchase-orders') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('list-purchase-orders')); ?>" aria-expanded="false"><i
                                        class="fa big-icon fa-envelope icon-wrap"></i> <span
                                        class="mini-click-non">Purchase order need to check</span></a>
                            </li>

                            <li
                                class="nav-item <?php echo e(request()->is('owner/list-approved-purchase-orders-owner') ? 'active' : ''); ?>">
                                <a title="Inbox" href="<?php echo e(route('list-approved-purchase-orders-owner')); ?>"><i
                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                        class="mini-sub-pro">Purchase Order Approved</span></a>
                            </li>
                            <li
                                class="nav-item <?php echo e(request()->is('owner/list-owner-submited-po-to-vendor') ? 'active' : ''); ?>">
                                <a title="Inbox" href="<?php echo e(route('list-owner-submited-po-to-vendor')); ?>"><i
                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                        class="mini-sub-pro">Submitted PO by Vendor</span></a>
                            </li>
                            <li class="nav-item <?php echo e(request()->is('owner/list-owner-gatepass') ? 'active' : ''); ?>">
                            <a title="Inbox" href="<?php echo e(route('list-owner-gatepass')); ?>"><i
                                    class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                    class="mini-sub-pro">Security Created Gate Pass</span></a>
                            </li>
                            
                            <li
                            class="nav-item <?php echo e(Request::is('list-rejected-chalan-po-wise') ? 'active' : ''); ?>">
                            <a title="Inbox"
                                href="<?php echo e(route('list-rejected-chalan-po-wise')); ?>"><i
                                    class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                    class="mini-sub-pro">PO wise Rejected Chalan</span></a>
                        </li>
                            
                            <li
                                class="nav-item <?php echo e(request()->is('owner/list-po-recived-for-approval-payment') ? 'active' : ''); ?>">
                                <a title="Inbox" href="<?php echo e(route('list-po-recived-for-approval-payment')); ?>"><i
                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                        class="mini-sub-pro">PO Payment Release Request</span></a>
                            </li>
                            <li
                            class="nav-item <?php echo e(request()->is('owner/list-po-recived-for-approval-payment') ? 'active' : ''); ?>">
                            <a title="Inbox" href="<?php echo e(route('list-po-recived-for-approval-payment')); ?>"><i
                                    class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                    class="mini-sub-pro">Logistics Dept Received Product completed list</span></a>
                        </li>
                            <li
                            class="nav-item <?php echo e(request()->is('owner/list-product-dispatch-completed') ? 'active' : ''); ?>">
                            <a title="Inbox" href="<?php echo e(route('list-product-dispatch-completed')); ?>"><i
                                    class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                    class="mini-sub-pro">Dispatch Completed</span></a>
                        </li> 
                            
                            <li><a title="Inbox" href="<?php echo e(route('list-rules-regulations')); ?>"><i
                                class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                class="mini-sub-pro">Rules and Regulations</span></a></li>
                                
                        </ul>
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.PURCHASE')): ?>
                        <li class="<?php echo e(Request::is('list-purchase') ? 'active' : ''); ?>">
                            <a class="has-arrow" href="<?php echo e(route('list-purchase')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Purchase
                                    Orders</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li class="nav-item <?php echo e(Request::is('list-purchase') ? 'active' : ''); ?>"><a
                                        title="Inbox" href="<?php echo e(route('list-purchase')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Purchase Orders To Be Finalize</span></a></li>
                                            
                            </ul>
                        </li>
                        <li class="<?php echo e(Request::is('list-vendor') ? 'active' : ''); ?>">
                            <a class="has-arrow" href="<?php echo e(route('list-vendor')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Vendor</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li class="nav-item <?php echo e(Request::is('list-vendor') ? 'active' : ''); ?>"><a
                                        title="Inbox" href="<?php echo e(route('list-vendor')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Vendor List</span></a></li>
                            </ul>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('purchase/list-tax') ? 'active' : ''); ?>">
                            <a class="" href="<?php echo e(route('list-tax')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Tax</span></a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('purchase/list-part-item') ? 'active' : ''); ?>">
                            <a class="" href="<?php echo e(route('list-part-item')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Part Item</span></a>
                        </li>
                        <li class="<?php echo e(Request::is('list-approved-purchase-orders') ? 'active' : ''); ?>">
                            <a class="has-arrow" href="<?php echo e(route('list-approved-purchase-orders')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Purchase Order Status</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li
                                    class="nav-item <?php echo e(request()->is('purchase/list-purchase-orders-sent-to-owner') ? 'active' : ''); ?>">
                                    <a href="<?php echo e(route('list-purchase-orders-sent-to-owner')); ?>"
                                        aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                            class="mini-click-non">Purchase Order Submited For Approval</span></a>
                                </li>

                                <li
                                    class="nav-item <?php echo e(Request::is('list-approved-purchase-orders') ? 'active' : ''); ?>">
                                    <a title="Inbox" href="<?php echo e(route('list-approved-purchase-orders')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Purchase Order Approved</span></a>
                                </li>

                                <li
                                    class="nav-item <?php echo e(Request::is('list-purchase-order-approved-sent-to-vendor') ? 'active' : ''); ?>">
                                    <a title="Inbox"
                                        href="<?php echo e(route('list-purchase-order-approved-sent-to-vendor')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Purchase Order Sent To Vendor</span></a>
                                </li>
                                <li
                                class="nav-item <?php echo e(Request::is('list-rejected-chalan-po-wise') ? 'active' : ''); ?>">
                                <a title="Inbox"
                                    href="<?php echo e(route('list-rejected-chalan-po-wise')); ?>"><i
                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                        class="mini-sub-pro">PO wise Rejected Chalan List</span></a>
                            </li>
                            </ul>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('purchase/list-submited-po-to-vendor') ? 'active' : ''); ?>">
                            <a class="" href="<?php echo e(route('list-submited-po-to-vendor')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Submited PO by Vendor List</span></a>
                        </li>

                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.DESIGNER')): ?>
                        <li 
                            class="nav-item <?php echo e(request()->is('designdept/list-new-requirements-received-for-design') ? 'active' : ''); ?>">
                            <a class="" href="<?php echo e(route('list-new-requirements-received-for-design')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">New Business<br> Received For Design</span></a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('designdept/list-design-upload') ? 'active' : ''); ?>">
                            <a class="" href="<?php echo e(route('list-design-upload')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Designs Sent To Production</span></a>
                        </li>

                        <li class="nav-item <?php echo e(request()->is('designdept/list-reject-design-from-prod') ? 'active' : ''); ?>">
                            <a class="" href="<?php echo e(route('list-reject-design-from-prod')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Rejected Design List</span></a>
                        </li>


                        
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.PRODUCTION')): ?>
                        <ul class="sidebar-menu">
                            <li
                                class="nav-item <?php echo e(request()->is('proddept/list-new-requirements-received-for-production') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('list-new-requirements-received-for-production')); ?>">
                                    <i class="fa big-icon fa-files-o icon-wrap"></i>
                                    <span class="mini-click-non">New Design List</span>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(request()->is('proddept/list-accept-design*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('list-accept-design')); ?>">
                                    <i class="fa fa-paper-plane icon-wrap"></i>
                                    <span class="mini-click-non">Accepted Design List</span>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(request()->is('proddept/list-reject-design') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('list-reject-design')); ?>">
                                    <i class="fa fa-frown-o icon-wrap"></i>
                                    <span class="mini-click-non">Rejected Design List</span>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(request()->is('proddept/list-revised-design') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('list-revised-design')); ?>">
                                    <i class="fa fa-fighter-jet icon-wrap"></i>
                                    <span class="mini-click-non">Revised Design List</span>
                                </a>
                            </li>

                            <li class="nav-item <?php echo e(request()->is('proddept/list-material-recived') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('list-material-recived')); ?>">
                                    <i class="fa fa-inbox icon-wrap"></i>
                                    <span class="mini-click-non">Material Received For Production</span>
                                </a>
                            </li>
                            <li class="nav-item <?php echo e(request()->is('proddept/list-final-production-completed') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('list-final-production-completed')); ?>">
                                    <i class="fa fa-inbox icon-wrap"></i>
                                    <span class="mini-click-non">Production Completed</span>
                                </a>
                            </li>
                        </ul>

                        
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.SECURITY')): ?>
                        <li>
                        <li class="nav-item <?php echo e(request()->is('search-by-po-no') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('search-by-po-no')); ?>">
                                <i class="fa fa-frown-o icon-wrap"></i>
                                <span class="mini-click-non">Search By PO No</span>
                            </a>
                        </li>


                        <a class="has-arrow" href="<?php echo e(route('list-gatepass')); ?>" aria-expanded="false"><i
                                class="fa big-icon fa-envelope icon-wrap"></i> <span class="mini-click-non">Gate
                                Pass</span></a>
                        <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="Inbox" href="<?php echo e(route('list-gatepass')); ?>"><i
                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                        class="mini-sub-pro">List Gate Pass</span></a></li>
                        </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-security-remark')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Remark</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-security-remark')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Remark</span></a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.QUALITY')): ?>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-grn')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span class="mini-click-non">GRN
                                    Form</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-grn')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List GRN</span></a></li>
                            </ul>
                        </li>
                       

                        <li class="nav-item <?php echo e(request()->is('list-material-sent-to-quality') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('list-material-sent-to-quality')); ?>">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">Material Sent to Store</span>
                            </a>
                        </li>
                        <li
                                class="nav-item <?php echo e(Request::is('list-rejected-chalan-po-wise') ? 'active' : ''); ?>">
                                <a title="Inbox"
                                    href="<?php echo e(route('list-rejected-chalan-po-wise')); ?>"><i
                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                        class="mini-sub-pro">PO wise Rejected Chalan</span></a>
                            </li>
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.STORE')): ?>
                    
                        <li class="nav-item <?php echo e(request()->is('storedept/list-accepted-design-from-prod') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('list-accepted-design-from-prod')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span class="mini-click-non">All
                                    New Requirements</span></a>
                        </li>

                        <li class="nav-item <?php echo e(request()->is('storedept/list-material-sent-to-prod') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('list-material-sent-to-prod')); ?>">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">Requirements Sent To Production</span>
                            </a>
                        </li>

                        <li class="nav-item <?php echo e(request()->is('storedept/list-material-sent-to-purchase') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('list-material-sent-to-purchase')); ?>">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">Material For Purchase</span>
                            </a>
                        </li>

                        <li
                            class="nav-item <?php echo e(request()->is('storedept/list-material-received-from-quality') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('list-material-received-from-quality')); ?>">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">Material Received From Quality</span>
                            </a>
                        </li>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-rejected-chalan')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span class="mini-click-non">Rejected Chalan
                                    </span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-rejected-chalan')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">List Rejected Chalan</span></a></li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.HR')): ?>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-users')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Employee</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-users')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Add Employee</span></a></li>
                            </ul>
                        </li>
                        <li><a title="Inbox" href="<?php echo e(route('list-yearly-leave-management')); ?>"><i
                                    class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                    class="mini-sub-pro">Add Yearly Leave</span></a></li>



                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-leaves-acceptedby-hr')); ?>"
                                aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                    class="mini-click-non">Leave Management</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-leaves-acceptedby-hr')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Leave Request</span></a></li>

                                <li><a title="Inbox" href="<?php echo e(route('list-leaves-approvedby-hr')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Leave Approved</span></a></li>

                                <li><a title="Inbox" href="<?php echo e(route('list-leaves-not-approvedby-hr')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Leave Not Approved</span></a></li>
                            </ul>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('list-notice') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('list-notice')); ?>">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">Add Notice</span>
                            </a>
                        </li>

                        <a href="<?php echo e(route('list-notice')); ?>">
                            <i class="fa big-icon fa-envelope icon-wrap"></i>
                            <span class="mini-click-non">Notice</span>
                        </a>
                    <?php endif; ?>

                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.FINANCE')): ?>
                        <li class="nav-item <?php echo e(request()->is('list-sr-and-gr-genrated-business') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('list-sr-and-gr-genrated-business')); ?>">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">Need to check for Payment</span>
                            </a>
                        </li>

                        <li class="nav-item <?php echo e(request()->is('list-po-sent-for-approval') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('list-po-sent-for-approval')); ?>">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">PO Submited For Sanction For Payment</span>
                            </a>
                        </li>


                        <li
                            class="nav-item <?php echo e(request()->is('list-po-sanction-and-need-to-do-payment-to-vendor') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('list-po-sanction-and-need-to-do-payment-to-vendor')); ?>">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">PO Pyament Need To Release</span>
                            </a>
                        </li>

                        <li class="nav-item <?php echo e(request()->is('recive-logistics-list') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('recive-logistics-list')); ?>">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">Recive Logistics List</span>
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('list-send-to-dispatch') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('list-send-to-dispatch')); ?>">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">Product Submited to Dispatch</span>
                            </a>
                        </li>
                    <?php endif; ?>


                    <?php if(session()->get('role_id') == config('constants.ROLE_ID.LOGISTICS')): ?>
                    <li class="nav-item <?php echo e(request()->is('list-final-production-completed-recive-to-logistics') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('list-final-production-completed-recive-to-logistics')); ?>">
                            <i class="fa big-icon fa-envelope icon-wrap"></i>
                            <span class="mini-click-non">Production Completed</span>
                        </a>
                    </li>

                    <li class="nav-item <?php echo e(request()->is('list-logistics') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('list-logistics')); ?>">
                            <i class="fa big-icon fa-envelope icon-wrap"></i>
                            <span class="mini-click-non">List Logistics</span>
                        </a>
                    </li>


                    <li
                        class="nav-item <?php echo e(request()->is('list-send-to-fianance-by-logistics') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('list-send-to-fianance-by-logistics')); ?>">
                            <i class="fa big-icon fa-envelope icon-wrap"></i>
                            <span class="mini-click-non">Submited by Fianance</span>
                        </a>
                    </li>
                <?php endif; ?>

                <?php if(session()->get('role_id') == config('constants.ROLE_ID.DISPATCH')): ?>
                <li class="nav-item <?php echo e(request()->is('list-final-production-completed-received-from-fianance') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('list-final-production-completed-received-from-fianance')); ?>">
                        <i class="fa big-icon fa-envelope icon-wrap"></i>
                        <span class="mini-click-non">Received From Finance</span>
                    </a>
                </li>

                <li class="nav-item <?php echo e(request()->is('list-dispatch') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('list-dispatch')); ?>">
                        <i class="fa big-icon fa-envelope icon-wrap"></i>
                        <span class="mini-click-non">Completed Dispatch</span>
                    </a>
                </li>
            <?php endif; ?>
                    <?php if(session()->get('user_id')): ?>
                        <li>
                            <a class="has-arrow" href="<?php echo e(route('list-leaves')); ?>" aria-expanded="false"><i
                                    class="fa big-icon fa-envelope icon-wrap"></i> <span class="mini-click-non">Leaves
                                    Request</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                                <li><a title="Inbox" href="<?php echo e(route('list-leaves')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Add Leaves Request</span></a></li>
                            </ul>
                        </li>
                        <li class="nav-item <?php echo e(request()->is('particular-notice-department-wise') ? 'active' : ''); ?>">
                            <a href="<?php echo e(route('particular-notice-department-wise')); ?>">
                                <i class="fa big-icon fa-envelope icon-wrap"></i>
                                <span class="mini-click-non">Notice</span>
                            </a>
                        </li>
                        
                    <?php endif; ?>

                       <?php if(session()->get('role_id') == config('constants.ROLE_ID.CMS')): ?>
                       <li>
                        <a class="has-arrow" href="<?php echo e(route('list-product')); ?>"
                            aria-expanded="false"><i class="fa big-icon fa-envelope icon-wrap"></i> <span
                                class="mini-click-non">CMS</span></a>
                        <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="Inbox" href="<?php echo e(route('list-product')); ?>"><i
                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                        class="mini-sub-pro">Product</span></a></li>

                            <li><a title="Inbox" href="<?php echo e(route('list-services')); ?>"><i
                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                        class="mini-sub-pro">Services</span></a></li>

                            <li><a title="Inbox" href="<?php echo e(route('list-testimonial')); ?>"><i
                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                        class="mini-sub-pro">Testimonial</span></a></li>
                                        
                            <li><a title="Inbox" href="<?php echo e(route('list-director-desk')); ?>"><i
                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                            class="mini-sub-pro">Director Desk</span></a></li> 
                            <li><a title="Inbox" href="<?php echo e(route('list-vision-mission')); ?>"><i
                                                class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                                class="mini-sub-pro">Vision Mission</span></a></li> 
                            <li><a title="Inbox" href="<?php echo e(route('list-team')); ?>"><i
                                                    class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                                    class="mini-sub-pro">Team</span></a></li>   
                            <li><a title="Inbox" href="<?php echo e(route('list-testimonial')); ?>"><i
                                                        class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                                        class="mini-sub-pro">Testimonial</span></a></li> 
                            <li><a title="Inbox" href="<?php echo e(route('list-contactus-form')); ?>"><i
                                                            class="fa fa-inbox sub-icon-mg" aria-hidden="true"></i> <span
                                                            class="mini-sub-pro">Contactus Form </span></a></li> 
                                                                 
                        </ul>
                    </li>                   
                    <?php endif; ?>

                    
                    

                </ul>
            </nav>
        </div>
    </nav>
</div>
<div class="all-content-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="logo-pro">
                    <a href="<?php echo e(route('login')); ?>"><img class="main-logo"
                            src="<?php echo e(asset('img/logo/logo_updated.png')); ?>" alt=""></a>
                </div>
            </div>
        </div>
    </div>
    <div class="header-advance-area">
        <div class="header-top-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="header-top-wraper">
                            <div class="row">
                                <div class="col-lg-1 col-md-0 col-sm-1 col-xs-12">
                                    <div class="menu-switcher-pro">
                                        <button type="button" id="sidebarCollapse"
                                            class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
                                            <i class="fa fa-bars"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-7 col-sm-6 col-xs-12">
                                    <div class="header-top-menu tabl-d-n">
                                        <ul class="nav navbar-nav mai-top-nav">

                                        </ul>
                                    </div>
                                </div>
                                <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
                                    <div class="header-right-info">
                                        <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                            
                                            <li class="nav-item">
                                                <a href="#" data-toggle="dropdown" role="button"
                                                    aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa fa-bell"></i></i><span
                                                        class="">1</span>
                                                </a>
                                                
                                                <div role="menu"
                                                    class="notification-author dropdown-menu animated zoomIn">
                                                    <div class="notification-single-top" style="background-color: linear-gradient(178deg, #175CA2 0%, #121416 100%)">
                                                        <h1 style="color: #fff; ">Notifications</h1>
                                                    </div>
                                                    <ul class="notification-menu" style="background-color:#fff;">
                                                        <li>
                                                            <a href="#">
                                                             
                                                                <div class="notification-content" >
                                                                   
                                                                    <h2 style="color:#444;">Business Sent For Design</h2>
                                                                   
                                                                </div>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                    <div class="notification-view">
                                                        <a href="#">View All Notification</a>

                                                    </div>
                                                </div>
                                            </li>
                                            <li class="nav-item">
                                                <a href="#" data-toggle="dropdown" role="button"
                                                    aria-expanded="false" class="nav-link dropdown-toggle"
                                                    style="font-size: 16px !important;">
                                                    <i class="fa fa-user adminpro-user-rounded header-riht-inf"
                                                        aria-hidden="true"></i>
                                                    <?php echo e(ucwords(config('constants.ROLE_ID_NAME.' . Session::get('role_id')))); ?>

                                                    Department
                                                    <span class="admin-name"></span>
                                                    <i class="fa fa-angle-down adminpro-icon adminpro-down-arrow"></i>
                                                </a>
                                                <ul role="menu"
                                                    class="dropdown-header-top author-log dropdown-menu animated zoomIn">

                                                    <li><a href="<?php echo e(route('log-out')); ?>"><span
                                                                class="fa fa-lock author-log-ic"></span>
                                                            Log Out</a>
                                                    </li>
                                                </ul>
                                            </li>

                                        </ul>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <form method="POST" action="<?php echo e(url('/particular-notice-department-wise')); ?>" id="showform">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="show_id" id="show_id" value="">
    </form><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>