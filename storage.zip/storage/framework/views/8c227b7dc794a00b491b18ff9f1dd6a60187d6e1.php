
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('organizations.common-pages.purchase-order-view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="" style="margin-bottom: 70px;">
        <a href="<?php echo e(route('finalize-and-submit-mail-to-vendor', $purchase_order_id)); ?>"><button data-toggle="tooltip"
                title="Send Mail" class="pd-setting-ed"><i class="fa fa-check" aria-hidden="true"></i>Send Mail To
                Vendor</button></a>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/organizations/purchase/purchase/purchase-order-details.blade.php ENDPATH**/ ?>