

<?php $__env->startSection('content'); ?>
    <div class="data-table-area mg-tb-15">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="sparkline13-list">
                        <div class="sparkline13-hd">
                            <div class="main-sparkline13-hd">
                                <h1>Conatct Us <span class="table-project-n">Data</span> Table</h1>
                                
                            </div>
                        </div>                       
                        <div class="sparkline13-graph">
                            <div class="datatable-dashv1-list custom-datatable-overright">
                                <div id="toolbar">
                                    <select class="form-control">
                                        <option value="">Export Basic</option>
                                        <option value="all">Export All</option>
                                        <option value="selected">Export Selected</option>
                                    </select>
                                </div>


                                <?php echo $__env->make('admin.layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="table-responsive">
                                    <table id="table" data-toggle="table" data-pagination="true" data-search="true"
                                        data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true"
                                        data-key-events="true" data-show-toggle="true" data-resizable="true"
                                        data-cookie="true" data-cookie-id-table="saveId" data-show-export="true"
                                        data-click-to-select="true" data-toolbar="#toolbar">
                                        <thead>
                                            <tr>
                                                <th>Sr. No.</th>
                                                <th>Full Name</th>
                                                <th>Company Name</th>
                                                <th>Mobile Number</th>
                                                <th>Email Id</th>
                                                <th>Message</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $get_contactus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e(strip_tags($item->full_name)); ?></td>
                                                    <td><?php echo e(strip_tags($item->subject)); ?></td>
                                                    <td><?php echo e(strip_tags($item->mobile_number)); ?></td>
                                                    <td><?php echo e(strip_tags($item->email)); ?></td>
                                                    <td><?php echo e(strip_tags($item->message)); ?></td>
                                                    <td>
                                                        <div class="d-flex">
                                                            <a data-id="<?php echo e($item->id); ?>"
                                                                class="show-btn btn btn-sm btn-outline-primary m-1"
                                                                title="Show"><i class="fas fa-eye"></i></a>
                                                                <a href="<?php echo e(route('delete-contactus-form', base64_encode($item->id))); ?> "><button
                                                                    data-toggle="tooltip" title="Trash"
                                                                    class="pd-setting-ed"><i class="fa fa-trash"
                                                                        aria-hidden="true"></i></button></a>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <form method="POST" action="<?php echo e(url('/show-contactus-form')); ?>" id="showform">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="show_id" id="show_id" value="">
    </form>
    
    <!-- content-wrapper ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/admin/cms/contactus/list-contactus-form.blade.php ENDPATH**/ ?>