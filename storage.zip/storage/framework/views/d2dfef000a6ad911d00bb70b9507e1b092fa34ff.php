

<?php $__env->startSection('content'); ?>
<div class="data-table-area mg-tb-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="sparkline13-list">
                    <div class="sparkline13-hd">
                        <div class="main-sparkline13-hd">
                            <h1>Vision Mission <span class="table-project-n">Data</span> Table</h1>
                                <div class="form-group-inner login-btn-inner row">
                                    
                                <div class="col-lg-10"></div>
                            </div>
                        </div>
                    </div>
                    <div class="sparkline13-graph">
                        <div class="datatable-dashv1-list custom-datatable-overright">
                            <div id="toolbar">
                                <select class="form-control">
                                    <option value="">Export Basic</option>
                                    <option value="all">Export All</option>
                                    <option value="selected">Export Selected</option>
                                </select>
                            </div>                         
                            <div class="table-responsive"> 
                                <table id="table" data-toggle="table" data-pagination="true" data-search="true"
                                    data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true"
                                    data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true"
                                    data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true"
                                    data-toolbar="#toolbar">
                                    <thead>
                                        <tr>
                                            <th>Sr. No.</th>
                                            <th>Vision Description</th>
                                            <th>Mission Description </th>
                                            <th>Vision Image</th>
                                            <th>Mission Image</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $getOutput; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e(strip_tags($item->vision_description)); ?></td>
                                                        <td><?php echo e(strip_tags($item->mission_description)); ?></td>
                                                        <td> <img class="img-size"
                                                                src="<?php echo e(Config::get('DocumentConstant.VISION_MISSION_VIEW')); ?><?php echo e($item->vision_image); ?>"
                                                                alt="Vision Image" />
                                                        </td>
                                                        <td> <img class="img-size"
                                                            src="<?php echo e(Config::get('DocumentConstant.VISION_MISSION_VIEW')); ?><?php echo e($item->mission_image); ?>"
                                                            alt="Mission Image" />
                                                    </td>
                                                        <td>
                                                            <div class="d-flex">
                                                                <a href="<?php echo e(route('edit-vision-mission', base64_encode($item->id))); ?>"
                                                                    class="btn btn-sm btn-outline-primary m-1"
                                                                    title="Edit Slide"><i
                                                                        class="fas fa-pencil-alt"></i></a>

                                                                <a data-id="<?php echo e($item->id); ?>"
                                                                    class="show-btn btn btn-sm btn-outline-primary m-1"
                                                                    title="Show Slide "><i class="fas fa-eye"></i></a>                                                              
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

        <form method="POST" action="<?php echo e(url('/show-vision-mission')); ?>" id="showform">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="show_id" id="show_id" value="">
        </form>
      
       
        <!-- content-wrapper ends -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/admin/cms/vision-mission/list-vision-mission.blade.php ENDPATH**/ ?>