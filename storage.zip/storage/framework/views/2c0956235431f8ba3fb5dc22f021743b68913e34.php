
<?php $__env->startSection('content'); ?>
<style>
    label {
        margin-top: 20px;
    }
    label.error {
        color: red; /* Change 'red' to your desired text color */
        font-size: 12px; /* Adjust font size if needed */
        /* Add any other styling as per your design */
    }
</style>
<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="sparkline12-list">
            <div class="sparkline12-hd">
                <div class="main-sparkline12-hd">
                    <center><h1>Edit Leaves Data</h1></center>
                </div>
            </div>
            <div class="sparkline12-graph">
                <div class="basic-login-form-ad">
                    <div class="row">
                        <?php if(session('msg')): ?>
                            <div class="alert alert-<?php echo e(session('status')); ?>">
                                <?php echo e(session('msg')); ?>

                            </div>
                        <?php endif; ?>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <?php if(Session::get('status') == 'success'): ?>
                                <div class="col-12 grid-margin">
                                    <div class="alert alert-custom-success " id="success-alert">
                                        <button type="button"  data-bs-dismiss="alert"></button>
                                        <strong style="color: green;">Success!</strong> <?php echo e(Session::get('msg')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>

                            <?php if(Session::get('status') == 'error'): ?>
                                <div class="col-12 grid-margin">
                                    <div class="alert alert-custom-danger " id="error-alert">
                                        <button type="button"  data-bs-dismiss="alert"></button>
                                        <strong style="color: red;">Error!</strong> <?php echo session('msg'); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                            <div class="all-form-element-inner">
                                <form action="<?php echo e(route('update-yearly-leave-management')); ?>" id="editEmployeeForm" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group-inner">
                                        <input type="hidden" class="form-control" value="<?php echo e($editData->id); ?>" id="id" name="id" >
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6 col-sm-6">
                                                <div class="form-group">
                                                    <label for="leave_year">Year : </label>&nbsp;<span class="red-text">*</span>
                                                    <select class="form-control" id="dYear" name="leave_year">
                                                        <option selected value="">Select Year</option>
                                                        <?php for($year = date('Y'); $year >= 1950; $year--): ?>
                                                            <option value="<?php echo e($year); ?>"
                                                                <?php if(old('leave_year', $editData->leave_year) == $year): ?> selected <?php endif; ?>>
                                                                <?php echo e($year); ?></option>
                                                        <?php endfor; ?>
                                                    </select>
                                                    <label class="error py-2" for="leave_year" id="dYear_error"></label>
                                                    <?php if($errors->has('leave_year')): ?>
                                                        <span class="red-text"><?php echo e($errors->first('leave_year')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>

                                            <div class="col-lg-6 col-md-6 col-sm-6">
                                                <label for="name">Name :</label>&nbsp<span class="red-text">*</span>
                                                <div class="calendar-icon">
                                                    <input type="text" class="form-control custom-select-value" value="<?php if(old('name')): ?> <?php echo e(old('name')); ?><?php else: ?><?php echo e($editData->name); ?> <?php endif; ?>" id="name" name="name" placeholder="Enter foundation date">
                                                    <?php if($errors->has('name')): ?>
                                                        <span class="red-text"><?php echo e($errors->first('name')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-lg-6 col-md-6 col-sm-6">
                                                <label for="leave_count">Leave Count :</label>&nbsp<span class="red-text">*</span>
                                                <div class="calendar-icon">
                                                    <input type="text" class="form-control" id="leave_count"value="<?php if(old('leave_count')): ?> <?php echo e(old('leave_count')); ?><?php else: ?><?php echo e($editData->leave_count); ?> <?php endif; ?>" name="leave_count" placeholder="Enter leave count">
                                                    <?php if($errors->has('leave_count')): ?>
                                                        <span class="red-text"><?php echo e($errors->first('leave_count')); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>                                        
                                    </div>

                                    <div class="login-btn-inner">
                                        <div class="row">
                                            <div class="col-lg-5"></div>
                                            <div class="col-lg-7">
                                                <div class="login-horizental cancel-wp pull-left">
                                                    <a href="<?php echo e(route('list-yearly-leave-management')); ?>"><button class="btn btn-white" style="margin-bottom:50px">Cancel</button></a>
                                                    <button class="btn btn-sm btn-primary login-submit-cs" type="submit" style="margin-bottom:50px">Save Data</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script> <!-- Include SweetAlert library -->

<script>
jQuery.noConflict();
jQuery(document).ready(function ($) {

    $("#addForm").validate({
        rules: {
                leave_year: {
                    required: true,
                },
                name: {
                    required: true,
                },
                leave_count: {
                    required: true,
                },
                
            },
            messages: {
                leave_year: {
                    required: "Please select leave year.",
                },
                name: {
                    required: "Please enter leave name.",
                },
                leave_count: {
                    required: "Please enter leave count.",
                },
               
            },
        // submitHandler: function(form) {
        //     // Use SweetAlert to show a success message
        //     Swal.fire({
        //         icon: 'success',
        //         title: 'Success!',
        //         text: 'Employee added successfully.',
        //     }).then(function() {
        //         form.submit(); // Submit the form after the user clicks OK
        //     });
        // }
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerag_final_updated\resources\views/organizations/hr/yearly-leave-management/edit-yearly-leave-management.blade.php ENDPATH**/ ?>