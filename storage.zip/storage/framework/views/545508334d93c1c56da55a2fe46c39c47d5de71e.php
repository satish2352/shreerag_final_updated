
<?php $__env->startSection('content'); ?>
    <style>
        label {
            margin-top: 10px;
        }

        label.error {
            color: red;
            /* Change 'red' to your desired text color */
            font-size: 12px;
            /* Adjust font size if needed */
            /* Add any other styling as per your design */
        }
    </style>


<div class="container-fluid">    
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="sparkline12-list">
                <div class="sparkline12-hd">
                    <div class="main-sparkline12-hd">
                        <center>
                            <h1>Edit Store Receipt Data</h1>
                        </center>
                    </div>
                </div>
                <div class="sparkline12-graph">
                    <div class="basic-login-form-ad">
                        <div class="row">
                            <?php if(session('msg')): ?>
                                <div class="alert alert-<?php echo e(session('status')); ?>">
                                    <?php echo e(session('msg')); ?>

                                </div>
                            <?php endif; ?>

                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <?php if(Session::has('status')): ?>
                                    <div class="col-md-12">
                                        <div class="alert alert-<?php echo e(Session::get('status')); ?> alert-dismissible"
                                            role="alert">
                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                            <strong><?php echo e(ucfirst(Session::get('status'))); ?>!</strong>
                                            <?php echo e(Session::get('msg')); ?>

                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="all-form-element-inner">
                                        <form action="<?php echo e(route('update-store-receipt', $editData[0]->store_receipt_main_id)); ?>"
                                            method="POST" id="editDesignsForm" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="design_main_id"
                                                            id="" class="form-control"
                                                            value="<?php echo e($editData[0]->store_receipt_main_id); ?>"
                                                            placeholder="">
                                            <a
                                            
                                           > 
                                           <!-- <button type="button" name="add" id="add" class="btn btn-success">Add More</button></a> -->
                                            <div class="container-fluid">
                                                <!-- <?php if($errors->any()): ?>
                                                    <div class="alert alert-danger">
                                                        <ul>
                                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li><?php echo e($error); ?></li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>
                                                    </div>
                                                <?php endif; ?> -->

                                                <?php $__currentLoopData = $editData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $editDataNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($key == 0): ?>
                                                    <div class="form-group-inner">
                                                        <div class="row">
                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                    <label for="store_date">Date:</label>
                                                                    <input type="date" class="form-control" id="store_date"
                                                                    name="store_date" 
                                                                    value="<?php echo e($editDataNew->store_date); ?>">
                                                            </div>   

                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <label for="name">Name of Store Person :</label>
                                                                <input type="text" class="form-control" id="name"
                                                                    name="name" placeholder="Enter Name of Store Person"
                                                                    value="<?php echo e($editDataNew->name); ?>">
                                                            </div>

                                                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                <label for="contact_number">Contact No. :</label>
                                                                <input type="text" class="form-control" id="contact_number"
                                                                    name="contact_number" placeholder="Enter Contact No."
                                                                    value="<?php echo e($editDataNew->contact_number); ?>"
                                                                    pattern="[789]{1}[0-9]{9}" 
                                                                    oninput="this.value = this.value.replace(/[^0-9]/g, '').replace(/(\..*)\./g, '$1');" 
                                                                    maxlength="10" 
                                                                    minlength="10">
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <div style="margin-top:10px;"> 
                                                    <table class="table table-bordered" id="dynamicTable">
                                                        <tr>
                                                            <th>Quantity</th>
                                                            <th>Description</th>
                                                            <th>Price</th>
                                                            <th>Amount</th>
                                                            <th>Total</th>
                                                            <th>Action</th>
                                                        </tr>
                                                        <?php $__currentLoopData = $editData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $editDataNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                        
                                                            <tr>
                                                                <input type="hidden" name="design_count"
                                                                id="design_id_<?php echo e($key); ?>" class="form-control"
                                                                value="<?php echo e($key); ?>"
                                                                placeholder="">

                                                                <input type="hidden" name="design_id_<?php echo e($key); ?>"
                                                                    id="design_id_<?php echo e($key); ?>" class="form-control"
                                                                    value="<?php echo e($editDataNew->purchase_order_details_id); ?>"
                                                                    placeholder="">
                                                            
                                                                <td>
                                                                    <input type="text"
                                                                        name="quantity_<?php echo e($key); ?>"
                                                                        value="<?php echo e($editDataNew->quantity); ?>"
                                                                        placeholder="Enter Quantity"
                                                                        class="form-control" />
                                                                </td>
                                                                        
                                                                <td>
                                                                    <input type="text"
                                                                        name="description_<?php echo e($key); ?>"
                                                                        value="<?php echo e($editDataNew->description); ?>"
                                                                        placeholder="Enter description" class="form-control" />
                                                                </td>

                                                                <td>
                                                                    <input type="text"
                                                                        name="price_<?php echo e($key); ?>"
                                                                        value="<?php echo e($editDataNew->price); ?>"
                                                                        placeholder="Enter Price"
                                                                        class="form-control" />
                                                                </td>

                                                                <td>
                                                                    <input type="text"
                                                                        name="amount_<?php echo e($key); ?>"
                                                                        value="<?php echo e($editDataNew->amount); ?>"
                                                                        placeholder="Enter amount" class="form-control" />
                                                                </td>

                                                                <td>
                                                                    <input type="text"
                                                                        name="total_<?php echo e($key); ?>"
                                                                        value="<?php echo e($editDataNew->total); ?>"
                                                                        placeholder="Enter total" class="form-control" />
                                                                </td>

                                                                <td>
                                                                    <a data-id="<?php echo e($editDataNew->id); ?>"
                                                                        class="delete-btn btn btn-danger m-1"
                                                                        title="Delete Tender"><i
                                                                            class="fas fa-archive"></i></a>
                
                                                                    </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                    </table>
                                                </div>    
                                                                                                
                                                <?php $__currentLoopData = $editData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $editDataNew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($key == 0): ?>
                                                        <div class="form-group-inner">                                                           
                                                            <div class="row">
                                                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                    <label for="remark">Remark :</label>
                                                                    <input type="text" class="form-control" id="remark"
                                                                        name="remark" placeholder="Enter Remark here"
                                                                        value="<?php echo e($editDataNew->remark); ?>">
                                                                </div>                                                            
                                                            
                                                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                                                    <label for="signature">Image:</label>
                                                                    <input type="file" class="form-control"
                                                                        accept="image/*" id="signature" name="signature">
                                                                    <div id="oldImageDisplay">
                                                                        <?php if(isset($editDataNew->signature)): ?>
                                                                            <b>Image Preview: </b>
                                                                            <img src="<?php echo e(Config::get('FileConstant.STORE_RECEIPT_VIEW') . $editDataNew->signature); ?>"
                                                                                alt="Old Image" style="max-width: 100px;">
                                                                        <?php endif; ?>
                                                                    </div>
                                                                    <div id="selectedImageDisplay" style="display: none;">
                                                                        <b>Image Preview: </b>
                                                                        <img src="" alt="Selected Image"
                                                                            style="max-width: 100px;">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                
                                                <div class="login-btn-inner">
                                                    <div class="row">
                                                        <div class="col-lg-5"></div>
                                                        <div class="col-lg-7">
                                                            <div class="login-horizental cancel-wp pull-left">
                                                                <a href="<?php echo e(route('list-store-receipt')); ?>"
                                                                    class="btn btn-white"
                                                                    style="margin-bottom:50px">Cancel</a>
                                                                <button class="btn btn-sm btn-primary login-submit-cs"
                                                                    type="submit" style="margin-bottom:50px">Update
                                                                    Data</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


    <form method="POST" action="<?php echo e(route('delete-addmore')); ?>" id="deleteform">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="delete_id" id="delete_id" value="">
    </form>

    

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>

    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
    <script>
        $(document).ready(function() {
    var i = <?php echo count($editData); ?>; // Initialize i with the number of existing rows

    $("#add").click(function() {
        ++i;

        $("#dynamicTable").append(
            '<tr>  <input type="hidden" name="addmore[' + i + '][design_count]" class="form-control" value="' + i + '" placeholder=""> <input type="hidden" name="addmore[' + i + '][purchase_id]" class="form-control" value="' + i + '" placeholder=""><td><input type="text" name="addmore[' + i + '][design_name]" placeholder="Enter Product Name" class="form-control" /></td><td><input type="text" name="addmore[' + i + '][product_quantity]" placeholder="Enter Product Quantity" class="form-control" /></td><td><input type="text" name="addmore[' + i + '][product_size]" placeholder="Enter Product Price" class="form-control" /></td><td><input type="text" name="addmore[' + i + '][product_unit]" placeholder="Enter Product Unit" class="form-control" /></td><td> <a class="remove-tr delete-btn btn btn-danger m-1" title="Delete"><i class="fas fa-archive"></i></a></td></tr>'
        );
    });

    $(document).on("click", ".remove-tr", function() {
        $(this).parents("tr").remove();
    });
});

        // $(document).ready(function() {
        //     var i = <?php echo count($editData); ?>; // Initialize i with the number of existing rows

        //     $("#add").click(function() {
        //         ++i;

        //         $("#dynamicTable").append(
        //             '<tr>  <input type="hidden" name="addmore[' + i + '][design_count]" class="form-control" value="" placeholder=""><input type="hidden" name="addmore[' + i + '][design_id]" id="design_id" class="form-control" value="" placeholder=""><td><input type="text" name="addmore[' + i + '][design_name]" placeholder="Enter Product Name" class="form-control" /></td><td><input type="text" name="addmore[' + i + '][product_quantity]" placeholder="Enter Product Quantity" class="form-control" /></td><td><input type="text" name="addmore[' + i + '][product_size]" placeholder="Enter Product Price" class="form-control" /></td><td><input type="text" name="addmore[' + i + '][product_unit]" placeholder="Enter Product Unit" class="form-control" /></td><td><button class="delete-btn btn btn-danger m-1 remove-tr" type="button">Delete</button></td></tr>'
        //         );
        //     });

        //     $(document).on("click", ".remove-tr", function() {
        //         $(this).parents("tr").remove();
        //     });
        // });
    </script>

<script>
    $('.delete-btn').click(function(e) {

        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
        }).then((result) => {
            if (result.isConfirmed) {
                $("#delete_id").val($(this).attr("data-id"));
                $("#deleteform").submit();
            }
        })

    });
</script>


    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shreerang\resources\views/organizations/store/store-receipt/edit-store-receipt.blade.php ENDPATH**/ ?>